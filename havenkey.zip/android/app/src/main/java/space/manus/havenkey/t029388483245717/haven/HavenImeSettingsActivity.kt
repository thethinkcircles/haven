package space.manus.havenkey.t029388483245717.haven

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class HavenImeSettingsActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val prefs = getSharedPreferences("haven-keyboard", Context.MODE_PRIVATE)
    setContent {
      var row by remember { mutableStateOf(prefs.getBoolean("number_row", true)) }
      var haptics by remember { mutableStateOf(prefs.getBoolean("haptics", true)) }
      var silent by remember { mutableStateOf(prefs.getBoolean("silence", false)) }
      var dark by remember { mutableStateOf(prefs.getBoolean("dark_theme", false)) }
      var glide by remember { mutableStateOf(prefs.getBoolean("glide", true)) }
      var height by remember { mutableFloatStateOf(prefs.getInt("key_height", 42).toFloat()) }
      var language by remember { mutableStateOf(prefs.getString("language", "English (US)") ?: "English (US)") }
      var menu by remember { mutableStateOf(false) }
      MaterialTheme {
        Surface {
          Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Haven keyboard settings", style = MaterialTheme.typography.headlineSmall)
            SettingLine("Optional number row", row) { row = it; prefs.edit().putBoolean("number_row", it).apply() }
            SettingLine("Haptic feedback", haptics) { haptics = it; prefs.edit().putBoolean("haptics", it).apply() }
            SettingLine("Silence mode", silent) { silent = it; prefs.edit().putBoolean("silence", it).apply() }
            SettingLine("Dark keyboard", dark) { dark = it; prefs.edit().putBoolean("dark_theme", it).apply() }
            SettingLine("Glide typing", glide) { glide = it; prefs.edit().putBoolean("glide", it).apply() }
            Text("Key height · " + height.toInt() + " dp", style = MaterialTheme.typography.titleMedium)
            Slider(value = height, onValueChange = { height = it; prefs.edit().putInt("key_height", it.toInt()).apply() }, valueRange = 36f..56f, steps = 9)
            Text("Language layout", style = MaterialTheme.typography.titleMedium)
            Box {
              Button(onClick = { menu = true }) { Text(language) }
              DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                listOf("English (US)", "Español", "Français", "Deutsch").forEach { item ->
                  DropdownMenuItem(text = { Text(item) }, onClick = { language = item; menu = false; prefs.edit().putString("language", item).apply() })
                }
              }
            }
            Text("Haven works offline. Typing and settings stay on this device.")
          }
        }
      }
    }
  }
}

@Composable private fun SettingLine(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
  Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(title, modifier = Modifier.padding(top = 12.dp))
    Switch(checked = value, onCheckedChange = onChange)
  }
}
