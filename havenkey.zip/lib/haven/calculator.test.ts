import { describe, expect, it } from "vitest";
import { calculateDiscount, evaluateScientific } from "./calculator";

describe("Haven calculator logic", () => {
  it("calculates savings and optional tax locally", () => {
    expect(calculateDiscount(80, 25, 10)).toEqual({
      price: 80,
      savings: 20,
      discounted: 60,
      total: 66,
    });
  });

  it("evaluates scientific expressions in degrees", () => {
    expect(evaluateScientific("sqrt(16) + sin(30)", true)).toBeCloseTo(4.5);
  });

  it("supports radians, powers, constants and factorial", () => {
    expect(evaluateScientific("sin(pi / 2) + 2^3 + 4!", false)).toBeCloseTo(33);
  });

  it("rejects invalid expressions rather than evaluating arbitrary code", () => {
    expect(() => evaluateScientific("2 + process.exit()", false)).toThrow();
  });
});
