export type ToolId =
  | "harmony"
  | "bible"
  | "memory"
  | "plate"
  | "notes"
  | "journal"
  | "todo"
  | "followup"
  | "exercise"
  | "sleep"
  | "calendar"
  | "prayer"
  | "discount"
  | "calculator";

export const TOOLS: {
  id: ToolId;
  name: string;
  subtitle: string;
  icon: string;
  tint: "green" | "lavender" | "peach";
}[] = [
  {
    id: "harmony",
    name: "Gospel Harmony",
    subtitle: "The complete chronological sequence",
    icon: "auto-stories",
    tint: "green",
  },
  {
    id: "bible",
    name: "King James Bible",
    subtitle: "The full Bible · offline",
    icon: "menu-book",
    tint: "green",
  },
  {
    id: "memory",
    name: "Memory Builder",
    subtitle: "Keep what matters close",
    icon: "lightbulb-outline",
    tint: "lavender",
  },
  {
    id: "plate",
    name: "Plate",
    subtitle: "A gentle food log",
    icon: "restaurant",
    tint: "peach",
  },
  {
    id: "notes",
    name: "Sticky Notes",
    subtitle: "Capture it before it goes",
    icon: "sticky-note-2",
    tint: "lavender",
  },
  {
    id: "journal",
    name: "Journal",
    subtitle: "A little space to reflect",
    icon: "edit-note",
    tint: "peach",
  },
  {
    id: "todo",
    name: "To Do",
    subtitle: "A simple list of next steps",
    icon: "checklist",
    tint: "green",
  },
  {
    id: "followup",
    name: "Follow-up",
    subtitle: "Small steps, remembered",
    icon: "task-alt",
    tint: "green",
  },
  {
    id: "exercise",
    name: "Exercise",
    subtitle: "Move in your own rhythm",
    icon: "directions-run",
    tint: "peach",
  },
  {
    id: "sleep",
    name: "Sleep",
    subtitle: "Notice your rest",
    icon: "bedtime",
    tint: "lavender",
  },
  {
    id: "calendar",
    name: "Calendar",
    subtitle: "A simple offline calendar",
    icon: "calendar-month",
    tint: "lavender",
  },
  {
    id: "prayer",
    name: "Prayer",
    subtitle: "A private place to pray",
    icon: "volunteer-activism",
    tint: "peach",
  },
  {
    id: "discount",
    name: "Discount Calculator",
    subtitle: "Sale price · savings · tax",
    icon: "percent",
    tint: "peach",
  },
  {
    id: "calculator",
    name: "Scientific Calculator",
    subtitle: "Trigonometry · logs · powers",
    icon: "calculate",
    tint: "lavender",
  },
];

export const KJV_NOTICE =
  "King James Version text sourced from thiagobodruk/bible. Repository code and data collection are MIT-licensed; Bible translations remain property of their respective owners. KJV text is public domain in the United States; other jurisdictions may differ. See assets/data/third-party/bible-data-LICENSE and https://github.com/thiagobodruk/bible.";

export const BIBLE_BOOKS = [
  "Genesis",
  "Exodus",
  "Leviticus",
  "Numbers",
  "Deuteronomy",
  "Joshua",
  "Judges",
  "Ruth",
  "1 Samuel",
  "2 Samuel",
  "1 Kings",
  "2 Kings",
  "1 Chronicles",
  "2 Chronicles",
  "Ezra",
  "Nehemiah",
  "Esther",
  "Job",
  "Psalms",
  "Proverbs",
  "Ecclesiastes",
  "Song of Solomon",
  "Isaiah",
  "Jeremiah",
  "Lamentations",
  "Ezekiel",
  "Daniel",
  "Hosea",
  "Joel",
  "Amos",
  "Obadiah",
  "Jonah",
  "Micah",
  "Nahum",
  "Habakkuk",
  "Zephaniah",
  "Haggai",
  "Zechariah",
  "Malachi",
  "Matthew",
  "Mark",
  "Luke",
  "John",
  "Acts",
  "Romans",
  "1 Corinthians",
  "2 Corinthians",
  "Galatians",
  "Ephesians",
  "Philippians",
  "Colossians",
  "1 Thessalonians",
  "2 Thessalonians",
  "1 Timothy",
  "2 Timothy",
  "Titus",
  "Philemon",
  "Hebrews",
  "James",
  "1 Peter",
  "2 Peter",
  "1 John",
  "2 John",
  "3 John",
  "Jude",
  "Revelation",
];
