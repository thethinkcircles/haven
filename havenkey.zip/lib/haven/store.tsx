import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useColorScheme } from "react-native";
import type { ReactNode } from "react";
export type ThemeChoice = "system" | "light" | "dark";
export type KeyLayer =
  | "letters"
  | "numbers"
  | "symbols"
  | "emoji"
  | "clipboard"
  | "editor";
export type HavenRecord = {
  id: string;
  title: string;
  body: string;
  createdAt: string;
  done?: boolean;
};
export type ToolState = Record<string, HavenRecord[]>;
export type Clip = {
  id: string;
  text: string;
  createdAt: string;
  pinned: boolean;
};
export type Preferences = {
  theme: ThemeChoice;
  haptics: boolean;
  silence: boolean;
  language: string;
  keyHeight: number;
  glide: boolean;
  numberRow: boolean;
};
export type ToolPreferences = Record<string, Record<string, string>>;
const PREFS_KEY = "haven.preferences.v1",
  TOOLS_KEY = "haven.tool-records.v1",
  CLIPS_KEY = "haven.clipboard.v1",
  CUSTOM_KEY = "haven.tool-preferences.v1";
export const DEFAULT_PREFS: Preferences = {
  theme: "system",
  haptics: true,
  silence: false,
  language: "English (US)",
  keyHeight: 48,
  glide: true,
  numberRow: true,
};
const defaults: ToolState = {
  memory: [],
  plate: [],
  notes: [],
  journal: [],
  followup: [],
  todo: [],
  exercise: [],
  sleep: [],
  calendar: [],
  prayer: [],
};
type HavenContextValue = {
  prefs: Preferences;
  updatePrefs: (next: Partial<Preferences>) => void;
  tools: ToolState;
  addRecord: (tool: string, title: string, body: string) => void;
  toggleRecord: (tool: string, id: string) => void;
  removeRecord: (tool: string, id: string) => void;
  clips: Clip[];
  addClip: (text: string) => void;
  togglePin: (id: string) => void;
  removeClip: (id: string) => void;
  toolPrefs: ToolPreferences;
  updateToolPrefs: (tool: string, field: string, value: string) => void;
};
const HavenContext = createContext<HavenContextValue | null>(null);
const id = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
export function HavenProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  const [tools, setTools] = useState(defaults);
  const [clips, setClips] = useState<Clip[]>([]);
  const [toolPrefs, setToolPrefs] = useState<ToolPreferences>({});
  useEffect(() => {
    let active = true;
    Promise.all([
      AsyncStorage.getItem(PREFS_KEY),
      AsyncStorage.getItem(TOOLS_KEY),
      AsyncStorage.getItem(CLIPS_KEY),
      AsyncStorage.getItem(CUSTOM_KEY),
    ])
      .then(([p, t, c, x]) => {
        if (!active) return;
        try {
          if (p) setPrefs({ ...DEFAULT_PREFS, ...JSON.parse(p) });
        } catch {}
        try {
          if (t) setTools({ ...defaults, ...JSON.parse(t) });
        } catch {}
        try {
          if (c) setClips(JSON.parse(c));
        } catch {}
        try {
          if (x) setToolPrefs(JSON.parse(x));
        } catch {}
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);
  const updatePrefs = (next: Partial<Preferences>) =>
    setPrefs((prev) => {
      const val = { ...prev, ...next };
      void AsyncStorage.setItem(PREFS_KEY, JSON.stringify(val));
      return val;
    });
  const updateToolPrefs = (tool: string, field: string, value: string) =>
    setToolPrefs((prev) => {
      const val = { ...prev, [tool]: { ...prev[tool], [field]: value } };
      void AsyncStorage.setItem(CUSTOM_KEY, JSON.stringify(val));
      return val;
    });
  const addRecord = (tool: string, title: string, body: string) =>
    setTools((prev) => {
      const val = {
        ...prev,
        [tool]: [
          { id: id(), title, body, createdAt: new Date().toISOString() },
          ...(prev[tool] ?? []),
        ],
      };
      void AsyncStorage.setItem(TOOLS_KEY, JSON.stringify(val));
      return val;
    });
  const toggleRecord = (tool: string, recordId: string) =>
    setTools((prev) => {
      const val = {
        ...prev,
        [tool]: (prev[tool] ?? []).map((r) =>
          r.id === recordId ? { ...r, done: !r.done } : r,
        ),
      };
      void AsyncStorage.setItem(TOOLS_KEY, JSON.stringify(val));
      return val;
    });
  const removeRecord = (tool: string, recordId: string) =>
    setTools((prev) => {
      const val = {
        ...prev,
        [tool]: (prev[tool] ?? []).filter((r) => r.id !== recordId),
      };
      void AsyncStorage.setItem(TOOLS_KEY, JSON.stringify(val));
      return val;
    });
  const addClip = (text: string) => {
    const clean = text.trim();
    if (!clean) return;
    setClips((prev) => {
      const val = [
        {
          id: id(),
          text: clean,
          createdAt: new Date().toISOString(),
          pinned: false,
        },
        ...prev.filter((x) => x.text !== clean),
      ].slice(0, 30);
      void AsyncStorage.setItem(CLIPS_KEY, JSON.stringify(val));
      return val;
    });
  };
  const togglePin = (clipId: string) =>
    setClips((prev) => {
      const val = prev
        .map((x) => (x.id === clipId ? { ...x, pinned: !x.pinned } : x))
        .sort((a, b) => Number(b.pinned) - Number(a.pinned));
      void AsyncStorage.setItem(CLIPS_KEY, JSON.stringify(val));
      return val;
    });
  const removeClip = (clipId: string) =>
    setClips((prev) => {
      const val = prev.filter((x) => x.id !== clipId);
      void AsyncStorage.setItem(CLIPS_KEY, JSON.stringify(val));
      return val;
    });
  const value = useMemo(
    () => ({
      prefs,
      updatePrefs,
      tools,
      addRecord,
      toggleRecord,
      removeRecord,
      clips,
      addClip,
      togglePin,
      removeClip,
      toolPrefs,
      updateToolPrefs,
    }),
    [prefs, tools, clips, toolPrefs],
  );
  return (
    <HavenContext.Provider value={value}>{children}</HavenContext.Provider>
  );
}
export function useHaven() {
  const value = useContext(HavenContext);
  if (!value) throw new Error("useHaven must be used inside HavenProvider");
  return value;
}
export function useHavenColors() {
  const { prefs } = useHaven();
  const system = useColorScheme();
  const dark =
    prefs.theme === "dark" || (prefs.theme === "system" && system === "dark");
  return dark
    ? {
        bg: "#171914",
        surface: "#22251E",
        raised: "#2D3028",
        text: "#F5F3EB",
        muted: "#A6AA9A",
        line: "#3A3D34",
        green: "#B5C58B",
        greenSoft: "#303A29",
        lavender: "#383246",
        peach: "#4A372C",
      }
    : {
        bg: "#F6F5EF",
        surface: "#FFFFFF",
        raised: "#F1F0E8",
        text: "#22271E",
        muted: "#777B70",
        line: "#E7E7DE",
        green: "#6C7A50",
        greenSoft: "#E8EDDE",
        lavender: "#EEEAF5",
        peach: "#F8EAE0",
      };
}
