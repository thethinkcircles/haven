import { describe, expect, it } from "vitest";
import bibleSource from "../../assets/data/third-party/en_kjv.json";
import harmonySource from "./harmony-data.json";

type VerseRange = {
  startChapter: number;
  startVerse: number;
  endChapter: number;
  endVerse: number;
};
type Passage = { reference: string; ranges: VerseRange[] } | null;
type Book = { chapters: string[][] };
type HarmonyEntry = {
  id: number;
  sectionId: string;
  order: number;
  title: string;
  accounts: Record<string, Passage>;
  supplementary: { reference: string; ranges: VerseRange[] }[];
};
type HarmonyIndex = { eventCount: number; events: HarmonyEntry[] };

const bible = bibleSource as unknown as Book[];
const index = harmonySource as HarmonyIndex;
const books = [
  "Genesis",
  "Exodus",
  "Leviticus",
  "Numbers",
  "Deuteronomy",
  "Joshua",
  "Judges",
  "Ruth",
  "1 Samuel",
  "2 Samuel",
  "1 Kings",
  "2 Kings",
  "1 Chronicles",
  "2 Chronicles",
  "Ezra",
  "Nehemiah",
  "Esther",
  "Job",
  "Psalms",
  "Proverbs",
  "Ecclesiastes",
  "Song of Solomon",
  "Isaiah",
  "Jeremiah",
  "Lamentations",
  "Ezekiel",
  "Daniel",
  "Hosea",
  "Joel",
  "Amos",
  "Obadiah",
  "Jonah",
  "Micah",
  "Nahum",
  "Habakkuk",
  "Zephaniah",
  "Haggai",
  "Zechariah",
  "Malachi",
  "Matthew",
  "Mark",
  "Luke",
  "John",
  "Acts",
  "Romans",
  "1 Corinthians",
  "2 Corinthians",
  "Galatians",
  "Ephesians",
  "Philippians",
  "Colossians",
  "1 Thessalonians",
  "2 Thessalonians",
  "1 Timothy",
  "2 Timothy",
  "Titus",
  "Philemon",
  "Hebrews",
  "James",
  "1 Peter",
  "2 Peter",
  "1 John",
  "2 John",
  "3 John",
  "Jude",
  "Revelation",
];

function assertRange(reference: string, ranges: VerseRange[]) {
  const match = reference.match(/^(.+?)\s+\d+:/);
  expect(match, `unparseable reference: ${reference}`).not.toBeNull();
  const bookIndex = books.indexOf(match![1]);
  expect(bookIndex, `unknown KJV book in ${reference}`).toBeGreaterThanOrEqual(
    0,
  );
  const chapters = bible[bookIndex].chapters;
  for (const range of ranges) {
    expect(range.startChapter, reference).toBeGreaterThanOrEqual(1);
    expect(range.endChapter, reference).toBeGreaterThanOrEqual(
      range.startChapter,
    );
    expect(range.endChapter, reference).toBeLessThanOrEqual(chapters.length);
    expect(range.startVerse, reference).toBeGreaterThanOrEqual(1);
    expect(range.startVerse, reference).toBeLessThanOrEqual(
      chapters[range.startChapter - 1].length,
    );
    expect(range.endVerse, reference).toBeGreaterThanOrEqual(1);
    expect(range.endVerse, reference).toBeLessThanOrEqual(
      chapters[range.endChapter - 1].length,
    );
  }
}

describe("complete Gospel Harmony index", () => {
  it("contains every numbered source section in document order, including lettered sections", () => {
    expect(index.eventCount).toBe(185);
    expect(index.events).toHaveLength(185);
    expect(index.events.map((event) => event.order)).toEqual(
      Array.from({ length: 185 }, (_, i) => i + 1),
    );
    expect(index.events.map((event) => event.sectionId)).toContain("128a");
    expect(index.events.map((event) => event.sectionId)).toContain("128b");
    expect(new Set(index.events.map((event) => event.sectionId)).size).toBe(
      185,
    );
  });

  it("keeps every Gospel and supplementary citation within the bundled KJV book/chapter/verse bounds", () => {
    let gospelReferenceCount = 0;
    let supplementaryReferenceCount = 0;
    for (const event of index.events) {
      expect(Object.keys(event.accounts)).toEqual([
        "Matthew",
        "Mark",
        "Luke",
        "John",
      ]);
      for (const [book, passage] of Object.entries(event.accounts)) {
        if (!passage) continue;
        gospelReferenceCount += 1;
        expect(
          passage.reference.startsWith(`${book} `),
          passage.reference,
        ).toBe(true);
        expect(passage.ranges.length, passage.reference).toBeGreaterThan(0);
        assertRange(passage.reference, passage.ranges);
      }
      for (const passage of event.supplementary) {
        supplementaryReferenceCount += 1;
        assertRange(passage.reference, passage.ranges);
      }
    }
    expect(gospelReferenceCount).toBe(368);
    expect(supplementaryReferenceCount).toBe(8);
  });
});
