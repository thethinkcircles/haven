import { BIBLE_BOOKS } from "@/lib/haven/catalog";

export type VerseRange = {
  startChapter: number;
  startVerse: number;
  endChapter: number;
  endVerse: number;
};

type BibleBook = { chapters: string[][] };
let biblePromise: Promise<BibleBook[]> | null = null;

const GOSPEL_BOOK_INDEX: Record<string, number> = {
  mat: 39,
  mar: 40,
  luk: 41,
  jhn: 42,
  Matthew: 39,
  Mark: 40,
  Luke: 41,
  John: 42,
  Acts: 43,
  "1 Corinthians": 45,
};

async function loadBible(): Promise<BibleBook[]> {
  if (!biblePromise) {
    biblePromise = import("@/assets/data/third-party/en_kjv.json")
      .then((data) => (data.default ?? data) as BibleBook[])
      .catch(() => []);
  }
  return biblePromise;
}

export async function findGospelVerse(
  book: string,
  chapter: number,
  verse: number,
): Promise<string> {
  return getVerse(GOSPEL_BOOK_INDEX[book] ?? 39, chapter, verse);
}

export async function getGospelPassage(
  book: string,
  ranges: VerseRange[],
): Promise<string>;
export async function getGospelPassage(
  book: string,
  chapter: number,
  startVerse: number,
  endVerse: number,
): Promise<string>;
export async function getGospelPassage(
  book: string,
  rangesOrChapter: VerseRange[] | number,
  startVerse?: number,
  endVerse?: number,
): Promise<string> {
  const data = await loadBible();
  const bookIndex = GOSPEL_BOOK_INDEX[book] ?? BIBLE_BOOKS.indexOf(book);
  const chapters = bookIndex >= 0 ? (data[bookIndex]?.chapters ?? []) : [];
  const ranges: VerseRange[] =
    typeof rangesOrChapter === "number"
      ? [
          {
            startChapter: rangesOrChapter,
            startVerse: startVerse ?? 1,
            endChapter: rangesOrChapter,
            endVerse: endVerse ?? startVerse ?? 1,
          },
        ]
      : rangesOrChapter;

  return ranges
    .map((range) => {
      const passage: string[] = [];
      const firstChapter = Math.max(1, range.startChapter);
      const lastChapter = Math.min(chapters.length, range.endChapter);
      if (lastChapter < firstChapter) return "";

      for (let chapter = firstChapter; chapter <= lastChapter; chapter += 1) {
        const verses = chapters[chapter - 1] ?? [];
        const firstVerse =
          chapter === firstChapter ? Math.max(1, range.startVerse) : 1;
        const lastVerse =
          chapter === lastChapter
            ? Math.min(verses.length, range.endVerse)
            : verses.length;
        if (lastVerse >= firstVerse) {
          passage.push(...verses.slice(firstVerse - 1, lastVerse));
        }
      }
      return passage.join(" ");
    })
    .filter(Boolean)
    .join(" … ");
}

export async function getVerse(
  bookIndex: number,
  chapter: number,
  verse: number,
): Promise<string> {
  const data = await loadBible();
  return (
    data[bookIndex]?.chapters?.[chapter - 1]?.[verse - 1] ??
    "This verse is not available in the bundled text."
  );
}

export async function getChapter(
  bookIndex: number,
  chapter: number,
): Promise<string[]> {
  const data = await loadBible();
  return data[bookIndex]?.chapters?.[chapter - 1] ?? [];
}

export async function getChapterCount(bookIndex: number): Promise<number> {
  const data = await loadBible();
  return data[bookIndex]?.chapters?.length ?? 1;
}

export function gospelBookIndex(bookName: string) {
  return BIBLE_BOOKS.indexOf(bookName);
}
