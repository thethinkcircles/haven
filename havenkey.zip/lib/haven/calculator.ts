type Token = string;
function tokenize(input: string): Token[] {
  const compact = input
    .replace(/π/g, "pi")
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/−/g, "-")
    .replace(/\s+/g, "")
    .toLowerCase();
  const tokens = compact.match(
    /(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|pi|sqrt|sin|cos|tan|log|ln|abs|e|\^|[()+\-*/%!]/g,
  );
  if (!tokens || tokens.join("") !== compact)
    throw new Error("Use numbers, + − × ÷, parentheses, or a listed function.");
  return tokens;
}
export function evaluateScientific(expression: string, degrees = true): number {
  const t = tokenize(expression);
  let i = 0;
  const peek = () => t[i];
  const pop = () => t[i++];
  const angle = (v: number) => (degrees ? (v * Math.PI) / 180 : v);
  function primary(): number {
    const x = peek();
    if (x === "+") {
      pop();
      return primary();
    }
    if (x === "-") {
      pop();
      return -primary();
    }
    if (x === "(") {
      pop();
      const v = add();
      if (pop() !== ")") throw new Error("Missing closing parenthesis.");
      return v;
    }
    if (["sin", "cos", "tan", "sqrt", "log", "ln", "abs"].includes(x)) {
      const fn = pop();
      const arg = primary();
      if (fn === "sin") return Math.sin(angle(arg));
      if (fn === "cos") return Math.cos(angle(arg));
      if (fn === "tan") return Math.tan(angle(arg));
      if (fn === "sqrt") return Math.sqrt(arg);
      if (fn === "log") return Math.log10(arg);
      if (fn === "ln") return Math.log(arg);
      return Math.abs(arg);
    }
    if (x === "pi") {
      pop();
      return Math.PI;
    }
    if (x === "e") {
      pop();
      return Math.E;
    }
    const n = Number(pop());
    if (!Number.isFinite(n)) throw new Error("Enter a valid number.");
    return n;
  }
  function power(): number {
    let v = primary();
    if (peek() === "^") {
      pop();
      v = v ** power();
    }
    while (peek() === "!") {
      pop();
      const n = Math.floor(v);
      if (n < 0 || n > 170 || n !== v)
        throw new Error("Factorial accepts integers from 0 to 170.");
      let f = 1;
      for (let k = 2; k <= n; k++) f *= k;
      v = f;
    }
    if (peek() === "%") {
      pop();
      v /= 100;
    }
    return v;
  }
  function multiply(): number {
    let v = power();
    while (peek() === "*" || peek() === "/") {
      const op = pop();
      const b = power();
      v = op === "*" ? v * b : v / b;
    }
    return v;
  }
  function add(): number {
    let v = multiply();
    while (peek() === "+" || peek() === "-") {
      const op = pop();
      const b = multiply();
      v = op === "+" ? v + b : v - b;
    }
    return v;
  }
  const result = add();
  if (i < t.length) throw new Error(`Unexpected token ${t[i]}.`);
  if (!Number.isFinite(result))
    throw new Error("That calculation has no finite result.");
  return result;
}
export function calculateDiscount(
  price: number,
  percent: number,
  taxPercent = 0,
) {
  if (
    !Number.isFinite(price) ||
    !Number.isFinite(percent) ||
    !Number.isFinite(taxPercent) ||
    price < 0 ||
    percent < 0 ||
    percent > 100 ||
    taxPercent < 0
  )
    throw new Error("Enter a valid price, discount, and tax.");
  const savings = (price * percent) / 100;
  const discounted = price - savings;
  return {
    price,
    savings,
    discounted,
    total: discounted * (1 + taxPercent / 100),
  };
}
