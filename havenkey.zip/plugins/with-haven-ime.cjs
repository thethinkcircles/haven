const {
  withAndroidManifest,
  withDangerousMod,
  withAppBuildGradle,
  withProjectBuildGradle,
} = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

function withImeManifest(config) {
  return withAndroidManifest(config, (mod) => {
    const app = mod.modResults.manifest.application?.[0];
    if (!app) return mod;
    app.service = app.service ?? [];
    const pkg = config.android?.package || "space.manus.havenkey";
    const service = `${pkg}.haven.HavenImeService`;
    if (!app.service.some((item) => item.$?.["android:name"] === service)) {
      app.service.push({
        $: {
          "android:name": service,
          "android:label": "Haven Keyboard",
          "android:permission": "android.permission.BIND_INPUT_METHOD",
          "android:exported": "true",
        },
        "intent-filter": [
          { action: [{ $: { "android:name": "android.view.InputMethod" } }] },
        ],
        "meta-data": [
          {
            $: {
              "android:name": "android.view.im",
              "android:resource": "@xml/haven_ime",
            },
          },
        ],
      });
    }
    app.activity = app.activity ?? [];
    const settings = `${pkg}.haven.HavenImeSettingsActivity`;
    if (!app.activity.some((item) => item.$?.["android:name"] === settings)) {
      app.activity.push({
        $: {
          "android:name": settings,
          "android:label": "Haven Keyboard Settings",
          "android:exported": "true",
        },
      });
    }
    return mod;
  });
}

function withCompose(config) {
  config = withProjectBuildGradle(config, (mod) => {
    let source = mod.modResults.contents;
    if (!source.includes("compose-compiler-gradle-plugin")) {
      source = source.replace(
        /classpath\(['"]org\.jetbrains\.kotlin:kotlin-gradle-plugin['"]\)/,
        (match) =>
          `${match}\n    classpath('org.jetbrains.kotlin:compose-compiler-gradle-plugin:2.1.20')`,
      );
    }
    mod.modResults.contents = source;
    return mod;
  });

  return withAppBuildGradle(config, (mod) => {
    let source = mod.modResults.contents;
    const kotlinPlugin = 'apply plugin: "org.jetbrains.kotlin.android"';
    const composePlugin = 'apply plugin: "org.jetbrains.kotlin.plugin.compose"';
    if (!source.includes(composePlugin)) {
      source = source.replace(
        kotlinPlugin,
        `${kotlinPlugin}\n${composePlugin}`,
      );
    }
    if (!source.includes("haven-compose-bom")) {
      source += `
// haven-compose-bom: native Compose IME
android { buildFeatures { compose true } }
dependencies {
 implementation platform("androidx.compose:compose-bom:2025.01.00")
 implementation "androidx.compose.ui:ui"
 implementation "androidx.compose.material3:material3"
 implementation "androidx.compose.foundation:foundation"
 implementation "androidx.compose.ui:ui-tooling-preview"
 implementation "androidx.activity:activity-compose:1.10.0"
}
`;
    }
    mod.modResults.contents = source;
    return mod;
  });
}

const nativeSource = (pkg, scheme) => `package ${pkg}.haven

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputType
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.animateContentSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Olive = Color(0xFF6C7A50)
private val Ink = Color(0xFF24271F)
private val Well = Color(0xFFF0F0E8)
private val Keys = Color(0xFFFFFFFF)

class HavenImeService : InputMethodService() {
  var numberRow by mutableStateOf(true)
  var hapticsOn by mutableStateOf(true)
  var silenceMode by mutableStateOf(false)
  var darkTheme by mutableStateOf(false)
  var glideOn by mutableStateOf(true)
  var keyHeight by mutableIntStateOf(42)
  var language by mutableStateOf("English (US)")
  var clipboardItems by mutableStateOf(listOf<String>())
  var composing by mutableStateOf("")
  var suggestions by mutableStateOf(listOf<String>())
  private val localCorrections = mapOf(
    "teh" to listOf("the"), "hellp" to listOf("hello"), "helo" to listOf("hello"),
    "wrld" to listOf("world"), "thier" to listOf("their", "there"),
    "recieve" to listOf("receive"), "becuase" to listOf("because"),
    "woudl" to listOf("would"), "qeu" to listOf("que"),
    "bonjor" to listOf("bonjour"), "dnak" to listOf("danke"),
  )
  private val localWords = mapOf(
    "English (US)" to "about after again also always and any are around ask at back be because been before being between book both bring build by call came can change come could day did different do each end even every few find first for found from get give go good great had has have he help her here him his how I if in into is it its just keep kind know learn like little long look made make many may me more most much must my name near need never new next no not now of off old on one only open or other our out over own people place point put read really right said same saw say see seem she should small so some still such take tell than that the them then there these they thing think this time to too try turn under use very want was way we well went were what when where which while who why will with words work would write year yes you your".split(" "),
    "Español" to "a ahora al algo allí año aquí así aunque bien cada casa como con cuando dar de decir del desde día donde dos el ella en entre era es esa ese eso esta este esto estar hacer hasta hay la las le les lo los más me mi mismo mucho muy nada ni no nos o otra para pero por porque que quien se ser si sin sobre su sus también tener todo tu un una uno y ya yo".split(" "),
    "Français" to "à après avec avoir bien bon c cela ce ces comme comment dans de des deux dire du elle en encore être fait faire femme fois grand il ils je jour la le les leur lui mais même merci moi moins mon mot ne nos notre nous nouveau nuit ou par pas père petit plus pour pourquoi quand que qui rien sans se son sont sous sur ta te temps terre tout très tu un une vous".split(" "),
    "Deutsch" to "aber alle als also am an auch auf aus bei bin bis bitte das dass dein dem den der des die dies doch du durch ein eine einer er es etwas für ganz gegen genau gut habe haben hat hier hin ich im in ist ja jeder jetzt kein können kurz lang mehr mein mit muss nach nein nicht noch nun oder ohne schon sehr sein sie sind so über um und uns unter vom von vor was wenn wer wie wieder wir wo zu zum zur".split(" "),
  )

  private fun refresh() {
    val prefs = getSharedPreferences("haven-keyboard", Context.MODE_PRIVATE)
    numberRow = prefs.getBoolean("number_row", true)
    hapticsOn = prefs.getBoolean("haptics", true)
    silenceMode = prefs.getBoolean("silence", false)
    darkTheme = prefs.getBoolean("dark_theme", false)
    glideOn = prefs.getBoolean("glide", true)
    keyHeight = prefs.getInt("key_height", 42).coerceIn(36, 56)
    language = prefs.getString("language", "English (US)") ?: "English (US)"
  }

  private fun requestSuggestions(word: String) {
    val normalized = word.lowercase()
    if (normalized.length < 2) {
      suggestions = emptyList()
      return
    }
    val corrections = localCorrections[normalized] ?: emptyList()
    val prefixWords = localWords[language].orEmpty().asSequence()
      .filter { it.lowercase().startsWith(normalized) && it.lowercase() != normalized }
      .map { it.lowercase() }
      .take(2).toList()
    suggestions = (corrections + prefixWords).distinct().take(2)
  }

  fun typeText(text: String, secure: Boolean) {
    val connection = currentInputConnection ?: return
    if (!secure && text.isNotEmpty() && text.all { it.isLetter() } && composing.length + text.length <= 64) {
      composing += text
      connection.setComposingText(composing, 1)
      requestSuggestions(composing)
    } else {
      finishComposition()
      connection.commitText(text, 1)
    }
  }

  fun finishComposition() {
    currentInputConnection?.finishComposingText()
    composing = ""
    suggestions = emptyList()
  }

  fun deleteKey(secure: Boolean) {
    val connection = currentInputConnection ?: return
    if (!secure && composing.isNotEmpty()) {
      composing = composing.dropLast(1)
      if (composing.isEmpty()) {
        connection.setComposingText("", 1)
        connection.finishComposingText()
        suggestions = emptyList()
      } else {
        connection.setComposingText(composing, 1)
        requestSuggestions(composing)
      }
    } else {
      connection.deleteSurroundingText(1, 0)
    }
  }

  fun acceptSuggestion(word: String) {
    val candidate = if (composing.firstOrNull()?.isUpperCase() == true) word.replaceFirstChar { it.uppercase() } else word
    currentInputConnection?.setComposingText(candidate, 1)
    currentInputConnection?.finishComposingText()
    composing = ""
    suggestions = emptyList()
  }

  fun moveCursor(keyCode: Int, select: Boolean = false) {
    val connection = currentInputConnection ?: return
    finishComposition()
    val meta = if (select) KeyEvent.META_SHIFT_ON else 0
    connection.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
    connection.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
  }

  fun editorAction(id: Int, changesText: Boolean = false) {
    if (changesText) finishComposition()
    currentInputConnection?.performContextMenuAction(id)
  }

  fun playKeySound() {
    try {
      (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
        .playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
    } catch (_: Exception) { }
  }

  fun refreshClipboard() {
    val prefs = getSharedPreferences("haven-keyboard", Context.MODE_PRIVATE)
    val saved = try {
      val array = JSONArray(prefs.getString("clips", "[]") ?: "[]")
      (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
    } catch (_: Exception) { emptyList() }
    val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val current = try {
      manager.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.take(4000)?.trim()
    } catch (_: Exception) { null }
    clipboardItems = (if (!current.isNullOrBlank() && current !in saved) listOf(current) + saved else saved).take(20)
    prefs.edit().putString("clips", JSONArray(clipboardItems).toString()).apply()
  }

  fun removeClip(text: String) {
    clipboardItems = clipboardItems.filterNot { it == text }
    getSharedPreferences("haven-keyboard", Context.MODE_PRIVATE).edit()
      .putString("clips", JSONArray(clipboardItems).toString()).apply()
  }

  override fun onCreateInputView(): View {
    refresh()
    return ComposeView(this).apply { setContent { HavenKeyboard(this@HavenImeService) } }
  }

  override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
    super.onStartInputView(info, restarting)
    refresh()
    finishComposition()
  }
}

@Composable private fun HavenKeyboard(service: HavenImeService) {
  var layer by remember { mutableIntStateOf(0) }
  var caps by remember { mutableStateOf(false) }
  val info = service.currentInputEditorInfo
  val inputType = info?.inputType ?: 0
  val inputClass = inputType and InputType.TYPE_MASK_CLASS
  val variation = inputType and InputType.TYPE_MASK_VARIATION
  val secure = inputClass == InputType.TYPE_CLASS_NUMBER ||
    inputClass == InputType.TYPE_CLASS_PHONE ||
    variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
  LaunchedEffect(inputClass) {
    layer = if (inputClass == InputType.TYPE_CLASS_NUMBER || inputClass == InputType.TYPE_CLASS_PHONE) 1 else 0
  }
  val letterRows = when (service.language) {
    "Français" -> listOf("azertyuiop", "qsdfghjkl", "wxcvbnm")
    "Deutsch" -> listOf("qwertzuiop", "asdfghjkl", "yxcvbnm")
    else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
  }
  val symbolRows = listOf("1234567890", "@#\$%&-*+()", "!?\\\"':;/")
  val advancedRows = listOf("~\u0060|•√π÷×¶∆", "£¢€¥^°={}", "\\\\<>©®™✓")
  val numberRows = when (layer) { 1 -> symbolRows; 2 -> advancedRows; else -> letterRows }
  val background = if (service.darkTheme) Color(0xFF24271F) else Well
  val keyColor = if (service.darkTheme) Color(0xFF34372F) else Keys
  val textColor = if (service.darkTheme) Color(0xFFF4F1E8) else Ink
  val keyHeight = service.keyHeight.dp
  val view = LocalView.current

  fun input(value: String) = service.typeText(if (caps && layer == 0) value.uppercase() else value, secure)
  fun launch(tool: String) {
    service.finishComposition()
    try {
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse("${scheme}://tool/$tool"))
        .setPackage(service.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      service.startActivity(intent)
    } catch (_: Exception) { }
  }

  val toolItems = listOf(
    "Harmony" to "harmony", "Bible" to "bible", "Memory" to "memory",
    "Plate" to "plate", "Notes" to "notes", "Journal" to "journal",
    "To Do" to "todo", "Follow-up" to "followup", "Exercise" to "exercise",
    "Sleep" to "sleep", "Calendar" to "calendar", "Prayer" to "prayer",
    "Discount" to "discount", "Scientific" to "calculator",
  )

  Column(
    Modifier.fillMaxWidth().background(background).padding(horizontal = 4.dp, vertical = 5.dp).animateContentSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
      Text("haven", Modifier.weight(1f).padding(start = 7.dp), color = Olive, fontWeight = FontWeight.Bold, fontSize = 14.sp)
      listOf("?123", "=<>", "☺", "▤", "Edit", "⌄").forEachIndexed { index, label ->
        TextButton(onClick = {
          when (index) {
            0 -> { service.finishComposition(); layer = if (layer == 1) 0 else 1 }
            1 -> { service.finishComposition(); layer = if (layer == 2) 0 else 2 }
            2 -> { service.finishComposition(); layer = 3 }
            3 -> { service.finishComposition(); layer = 4; if (!secure) service.refreshClipboard() }
            4 -> { service.finishComposition(); layer = 5 }
            else -> service.requestHideSelf(0)
          }
        }) {
          Text(label, color = if ((index == 0 && layer == 1) || (index == 1 && layer == 2) || (index == 2 && layer == 3) || (index == 3 && layer == 4) || (index == 4 && layer == 5)) Olive else textColor, fontSize = 11.sp)
        }
      }
    }

    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).height(36.dp), verticalAlignment = Alignment.CenterVertically) {
      toolItems.forEach { (label, id) ->
        TextButton(onClick = { launch(id) }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
          Text(label, color = Olive, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    if (layer == 0 && !secure && service.composing.isNotEmpty()) {
      Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).height(38.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        (listOf(service.composing) + service.suggestions).distinct().take(3).forEach { word ->
          TextButton(onClick = { service.acceptSuggestion(word) }) {
            Text(word, color = if (word == service.composing) Olive else textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
          }
        }
      }
    }

    when (layer) {
      3 -> {
        val emojis = listOf("😀", "😂", "🥹", "😍", "😊", "🙏", "❤️", "✨", "🔥", "👍", "🤔", "🌿", "📖", "🙌", "💛", "🕊️", "☀️", "🎉", "🤍", "🫶")
        emojis.chunked(5).forEach { chunk ->
          Row(Modifier.widthIn(max = 800.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            chunk.forEach { emoji -> TextButton(onClick = { input(emoji) }) { Text(emoji, fontSize = 23.sp) } }
          }
        }
      }
      4 -> {
        if (secure) {
          Text("Clipboard is disabled in secure fields.", Modifier.padding(14.dp), color = textColor, fontSize = 12.sp)
        } else {
          Column(Modifier.widthIn(max = 800.dp).fillMaxWidth().heightIn(max = 220.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (service.clipboardItems.isEmpty()) Text("No saved clips yet. Open clipboard after copying text.", Modifier.padding(12.dp), color = textColor, fontSize = 12.sp)
            service.clipboardItems.forEach { clip ->
              Row(Modifier.fillMaxWidth().background(keyColor, RoundedCornerShape(10.dp)).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { input(clip) }, modifier = Modifier.weight(1f)) { Text(clip.take(90), maxLines = 2, color = textColor, fontSize = 12.sp) }
                TextButton(onClick = { service.removeClip(clip) }) { Text("×", color = textColor) }
              }
            }
          }
        }
      }
      5 -> {
        Row(Modifier.widthIn(max = 800.dp).fillMaxWidth().horizontalScroll(rememberScrollState()).height(50.dp), verticalAlignment = Alignment.CenterVertically) {
          EditButton("◀", "Move cursor left", textColor) { service.moveCursor(KeyEvent.KEYCODE_DPAD_LEFT) }
          EditButton("▶", "Move cursor right", textColor) { service.moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT) }
          EditButton("⇦", "Select left", textColor) { service.moveCursor(KeyEvent.KEYCODE_DPAD_LEFT, true) }
          EditButton("⇨", "Select right", textColor) { service.moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT, true) }
          EditButton("All", "Select all", textColor) { service.editorAction(android.R.id.selectAll) }
          if (!secure) {
            EditButton("Cut", "Cut selection", textColor) { service.editorAction(android.R.id.cut, true); service.refreshClipboard() }
            EditButton("Copy", "Copy selection", textColor) { service.editorAction(android.R.id.copy); service.refreshClipboard() }
            EditButton("Paste", "Paste from clipboard", textColor) { service.editorAction(android.R.id.paste, true) }
            EditButton("Undo", "Undo edit", textColor) { service.editorAction(android.R.id.undo, true) }
            EditButton("Redo", "Redo edit", textColor) { service.editorAction(android.R.id.redo, true) }
          }
        }
      }
      else -> {
        if (layer == 0 && service.numberRow) KeyRow("1234567890", service, keyColor, textColor, keyHeight)
        if (layer == 0) {
          val gesture = if (service.glideOn && !secure) Modifier.pointerInput(letterRows, caps) {
            var path = StringBuilder()
            var last: Char? = null
            fun keyAt(point: Offset): Char? {
              val x = point.x / size.width.toFloat()
              val row = (point.y / (size.height / 3f)).toInt().coerceIn(0, 2)
              val (index, start, width) = when (row) {
                0 -> Triple((x * 10).toInt(), 0f, 1f)
                1 -> Triple(((x - 0.05f) / 0.90f * 9).toInt(), 0.05f, 0.90f)
                else -> {
                  val first = 1.35f / 9.7f
                  val letters = 7f / 9.7f
                  if (x < first || x > first + letters) return null
                  Triple(((x - first) / letters * 7).toInt(), first, letters)
                }
              }
              if (x < start || x > start + width) return null
              return letterRows[row].getOrNull(index.coerceIn(0, letterRows[row].lastIndex))
            }
            detectDragGestures(
              onDragStart = { point -> path = StringBuilder(); last = keyAt(point); last?.let(path::append) },
              onDrag = { change, _ ->
                val next = keyAt(change.position)
                if (next != null && next != last) { path.append(next); last = next }
                change.consume()
              },
              onDragEnd = {
                val compact = path.fold(StringBuilder()) { acc, char -> if (acc.isEmpty() || acc.last() != char) acc.append(char) else acc }
                if (compact.length > 1) {
                  service.typeText(if (caps) compact.toString().uppercase() else compact.toString(), false)
                  if (service.hapticsOn) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
              },
            )
          } else Modifier

          Box(Modifier.widthIn(max = 800.dp).fillMaxWidth().then(gesture)) {
            Column(Modifier.fillMaxWidth()) {
              Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.Center) {
                letterRows[0].forEach { char -> LetterKey(char, service, keyHeight, keyColor, textColor, caps, secure) { input(char.toString()) } }
              }
              Row(Modifier.fillMaxWidth(0.90f).align(Alignment.CenterHorizontally).padding(vertical = 2.dp), horizontalArrangement = Arrangement.Center) {
                letterRows[1].forEach { char -> LetterKey(char, service, keyHeight, keyColor, textColor, caps, secure) { input(char.toString()) } }
              }
              Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.Center) {
                KeyButton("⇧", service, Modifier.weight(1.35f).height(keyHeight), true, keyColor, textColor, onClick = { caps = !caps })
                letterRows[2].forEach { char -> LetterKey(char, service, keyHeight, keyColor, textColor, caps, secure) { input(char.toString()) } }
                KeyButton("⌫", service, Modifier.weight(1.35f).height(keyHeight), true, keyColor, textColor, onClick = { service.deleteKey(secure) })
              }
            }
          }
        } else {
          val rows = if (layer == 1) symbolRows else advancedRows
          Column(Modifier.widthIn(max = 800.dp).fillMaxWidth()) {
            rows.forEach { row ->
              Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.Center) {
                row.forEach { char -> KeyButton(char.toString(), service, Modifier.weight(1f).height(keyHeight), onClick = { input(char.toString()) }) }
              }
            }
          }
        }
        Row(Modifier.widthIn(max = 800.dp).fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.Center) {
          KeyButton(if (layer == 0) "?123" else "ABC", service, Modifier.weight(1.4f).height(keyHeight), true, keyColor, textColor, onClick = { service.finishComposition(); layer = if (layer == 0) 1 else 0 })
          KeyButton(",", service, Modifier.weight(.85f).height(keyHeight), onClick = { input(",") })
          KeyButton(service.language, service, Modifier.weight(4.8f).height(keyHeight), keyColor = keyColor, textColor = textColor, onClick = { input(" ") })
          KeyButton(".", service, Modifier.weight(.85f).height(keyHeight), onClick = { input(".") })
          KeyButton("↵", service, Modifier.weight(1.4f).height(keyHeight), true, keyColor, textColor, onClick = {
            service.finishComposition()
            val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: 0
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) service.currentInputConnection?.performEditorAction(action)
            else service.currentInputConnection?.commitText(10.toChar().toString(), 1)
          })
        }
      }
    }
  }
}

@Composable private fun RowScope.LetterKey(char: Char, service: HavenImeService, keyHeight: androidx.compose.ui.unit.Dp, keyColor: Color, textColor: Color, caps: Boolean, secure: Boolean, onClick: () -> Unit) {
  val accents = when (char.lowercaseChar()) {
    'a' -> listOf("á", "à", "â", "ä", "æ", "ã", "å")
    'e' -> listOf("é", "è", "ê", "ë")
    'i' -> listOf("í", "ì", "î", "ï")
    'o' -> listOf("ó", "ò", "ô", "ö", "œ", "õ")
    'u' -> listOf("ú", "ù", "û", "ü")
    'n' -> listOf("ñ")
    'c' -> listOf("ç")
    's' -> listOf("ß", "š")
    'y' -> listOf("ý", "ÿ")
    else -> emptyList()
  }
  KeyButton(if (caps) char.uppercase() else char.toString(), service, Modifier.weight(1f).height(keyHeight), keyColor = keyColor, textColor = textColor, alternates = accents, onAlternate = { service.typeText(it, secure) }, onClick = onClick)
}

@Composable private fun KeyRow(text: String, service: HavenImeService, keyColor: Color, textColor: Color, keyHeight: androidx.compose.ui.unit.Dp) {
  Row(Modifier.widthIn(max = 800.dp).fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.Center) {
    text.forEach { digit -> KeyButton(digit.toString(), service, Modifier.weight(1f).height(keyHeight * .82f), keyColor = keyColor, textColor = textColor, onClick = { service.typeText(digit.toString(), false) }) }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun KeyButton(
  label: String,
  service: HavenImeService,
  modifier: Modifier = Modifier,
  special: Boolean = false,
  keyColor: Color = Keys,
  textColor: Color = Ink,
  alternates: List<String> = emptyList(),
  onAlternate: (String) -> Unit = {},
  onClick: () -> Unit,
) {
  var open by remember { mutableStateOf(false) }
  val view = LocalView.current
  Box(modifier.padding(horizontal = 1.dp, vertical = 2.dp)) {
    Surface(
      modifier = Modifier.fillMaxSize().combinedClickable(
        onClick = {
          if (service.hapticsOn) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
          if (!service.silenceMode) service.playKeySound()
          onClick()
        },
        onLongClick = { if (alternates.isNotEmpty()) open = true },
      ),
      shape = RoundedCornerShape(8.dp),
      color = if (special) { if (service.darkTheme) Color(0xFF454A3D) else Color(0xFFDDE2D1) } else keyColor,
      shadowElevation = 1.dp,
    ) {
      Box(contentAlignment = Alignment.Center) {
        Text(label, color = textColor, fontSize = if (label.length > 1) 11.sp else 18.sp, fontWeight = FontWeight.Medium)
      }
    }
    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
      alternates.forEach { accent -> DropdownMenuItem(text = { Text(accent) }, onClick = { onAlternate(accent); open = false }) }
    }
  }
}

@Composable private fun EditButton(label: String, description: String, color: Color, onClick: () -> Unit) {
  TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 7.dp)) {
    Text(label, color = color, fontSize = 12.sp, modifier = Modifier.semantics { contentDescription = description }, maxLines = 1)
  }
}
`;

const settingsSource = (pkg) => `package ${pkg}.haven

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class HavenImeSettingsActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val prefs = getSharedPreferences("haven-keyboard", Context.MODE_PRIVATE)
    setContent {
      var row by remember { mutableStateOf(prefs.getBoolean("number_row", true)) }
      var haptics by remember { mutableStateOf(prefs.getBoolean("haptics", true)) }
      var silent by remember { mutableStateOf(prefs.getBoolean("silence", false)) }
      var dark by remember { mutableStateOf(prefs.getBoolean("dark_theme", false)) }
      var glide by remember { mutableStateOf(prefs.getBoolean("glide", true)) }
      var height by remember { mutableFloatStateOf(prefs.getInt("key_height", 42).toFloat()) }
      var language by remember { mutableStateOf(prefs.getString("language", "English (US)") ?: "English (US)") }
      var menu by remember { mutableStateOf(false) }
      MaterialTheme {
        Surface {
          Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Haven keyboard settings", style = MaterialTheme.typography.headlineSmall)
            SettingLine("Optional number row", row) { row = it; prefs.edit().putBoolean("number_row", it).apply() }
            SettingLine("Haptic feedback", haptics) { haptics = it; prefs.edit().putBoolean("haptics", it).apply() }
            SettingLine("Silence mode", silent) { silent = it; prefs.edit().putBoolean("silence", it).apply() }
            SettingLine("Dark keyboard", dark) { dark = it; prefs.edit().putBoolean("dark_theme", it).apply() }
            SettingLine("Glide typing", glide) { glide = it; prefs.edit().putBoolean("glide", it).apply() }
            Text("Key height · " + height.toInt() + " dp", style = MaterialTheme.typography.titleMedium)
            Slider(value = height, onValueChange = { height = it; prefs.edit().putInt("key_height", it.toInt()).apply() }, valueRange = 36f..56f, steps = 9)
            Text("Language layout", style = MaterialTheme.typography.titleMedium)
            Box {
              Button(onClick = { menu = true }) { Text(language) }
              DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                listOf("English (US)", "Español", "Français", "Deutsch").forEach { item ->
                  DropdownMenuItem(text = { Text(item) }, onClick = { language = item; menu = false; prefs.edit().putString("language", item).apply() })
                }
              }
            }
            Text("Haven works offline. Typing and settings stay on this device.")
          }
        }
      }
    }
  }
}

@Composable private fun SettingLine(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
  Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(title, modifier = Modifier.padding(top = 12.dp))
    Switch(checked = value, onCheckedChange = onChange)
  }
}
`;

function withNativeSource(config) {
  return withDangerousMod(config, [
    "android",
    async (mod) => {
      const pkg = mod.android?.package || "space.manus.havenkey";
      const scheme = typeof mod.scheme === "string" ? mod.scheme : "havenkey";
      const root = mod.modRequest.platformProjectRoot;
      const source = path.join(
        root,
        "app/src/main/java",
        ...pkg.split("."),
        "haven",
      );
      const xml = path.join(root, "app/src/main/res/xml");
      fs.mkdirSync(source, { recursive: true });
      fs.mkdirSync(xml, { recursive: true });
      fs.writeFileSync(
        path.join(xml, "haven_ime.xml"),
        `<?xml version="1.0" encoding="utf-8"?>\n<input-method xmlns:android="http://schemas.android.com/apk/res/android" android:supportsSwitchingToNextInputMethod="true" android:settingsActivity="${pkg}.haven.HavenImeSettingsActivity"><subtype android:label="English (US)" android:languageTag="en-US" android:imeSubtypeMode="keyboard"/><subtype android:label="Español" android:languageTag="es" android:imeSubtypeMode="keyboard"/><subtype android:label="Français" android:languageTag="fr" android:imeSubtypeMode="keyboard"/><subtype android:label="Deutsch" android:languageTag="de" android:imeSubtypeMode="keyboard"/></input-method>`,
      );
      fs.writeFileSync(
        path.join(source, "HavenImeService.kt"),
        nativeSource(pkg, scheme),
      );
      fs.writeFileSync(
        path.join(source, "HavenImeSettingsActivity.kt"),
        settingsSource(pkg),
      );
      return mod;
    },
  ]);
}

module.exports = function withHavenIme(config) {
  config = withImeManifest(config);
  config = withCompose(config);
  return withNativeSource(config);
};
