import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { useHaven, useHavenColors } from "@/lib/haven/store";
export default function TabLayout() {
  const c = useHavenColors();
  const insets = useSafeAreaInsets();
  const { prefs } = useHaven();
  const bottom = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: c.green,
        tabBarInactiveTintColor: c.muted,
        tabBarStyle: {
          height: 58 + bottom,
          paddingTop: 7,
          paddingBottom: bottom,
          backgroundColor: c.bg,
          borderTopColor: c.line,
          borderTopWidth: 1,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: "600" },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: ({ color }) => (
            <MaterialIcons name="home-filled" size={22} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="keyboard"
        options={{
          title: "Keyboard",
          tabBarIcon: ({ color }) => (
            <MaterialIcons name="keyboard-alt" size={22} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="tools"
        options={{
          title: "Tools",
          tabBarIcon: ({ color }) => (
            <MaterialIcons name="grid-view" size={22} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: "Settings",
          tabBarIcon: ({ color }) => (
            <MaterialIcons name="tune" size={22} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
