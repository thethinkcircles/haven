import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ScrollView, Text, View, Switch, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import {
  Card,
  Eyebrow,
  Heading,
  Pill,
  SectionTitle,
} from "@/components/haven/ui";
import { useHaven, useHavenColors } from "@/lib/haven/store";
export default function SettingsScreen() {
  const c = useHavenColors();
  const { prefs, updatePrefs } = useHaven();
  const ToggleRow = ({
    icon,
    title,
    body,
    value,
    onValueChange,
  }: {
    icon: string;
    title: string;
    body: string;
    value: boolean;
    onValueChange: (v: boolean) => void;
  }) => (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 12,
        paddingVertical: 13,
        borderBottomWidth: 1,
        borderBottomColor: c.line,
      }}
    >
      <MaterialIcons name={icon as any} size={20} color={c.green} />
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={{ color: c.text, fontSize: 14, fontWeight: "700" }}>
          {title}
        </Text>
        <Text style={{ color: c.muted, fontSize: 11, lineHeight: 16 }}>
          {body}
        </Text>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: c.line, true: c.green }}
        thumbColor="#fff"
      />
    </View>
  );
  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 34,
          gap: 22,
          maxWidth: 760,
          width: "100%",
          alignSelf: "center",
        }}
      >
        <View style={{ gap: 8 }}>
          <Eyebrow>MAKE IT YOURS</Eyebrow>
          <Heading sub="Thoughtful defaults. Your choice, always.">
            Settings.
          </Heading>
        </View>
        <View>
          <SectionTitle>Appearance</SectionTitle>
          <Card>
            <Text
              style={{
                color: c.text,
                fontSize: 13,
                fontWeight: "700",
                marginBottom: 10,
              }}
            >
              Theme
            </Text>
            <View style={{ flexDirection: "row", gap: 8 }}>
              {(["system", "light", "dark"] as const).map((value) => (
                <Pill
                  key={value}
                  label={
                    value === "system"
                      ? "System"
                      : value === "light"
                        ? "Light"
                        : "Dark"
                  }
                  active={prefs.theme === value}
                  onPress={() => updatePrefs({ theme: value })}
                />
              ))}
            </View>
          </Card>
        </View>
        <View>
          <SectionTitle>Keyboard</SectionTitle>
          <Card style={{ marginBottom: 10, backgroundColor: c.greenSoft }}>
            <Text style={{ color: c.text, fontSize: 12, lineHeight: 18 }}>
              These controls customize the in-app keyboard preview. After you
              enable Haven Keyboard in Android Settings → System → Keyboard →
              On-screen keyboard, configure the installed keyboard through its
              Haven Keyboard settings there.
            </Text>
          </Card>
          <Card style={{ paddingHorizontal: 14 }}>
            <ToggleRow
              icon="pin"
              title="Number row"
              body="Keep 0–9 above QWERTY. Turn it on or off any time."
              value={prefs.numberRow}
              onValueChange={(value) => updatePrefs({ numberRow: value })}
            />
            <ToggleRow
              icon="vibration"
              title="Haptic feedback"
              body="A light touch with each key. Uses device vibration."
              value={prefs.haptics}
              onValueChange={(value) => updatePrefs({ haptics: value })}
            />
            <ToggleRow
              icon="volume-off"
              title="Silence mode"
              body="Quiet keypresses. No keyboard sounds."
              value={prefs.silence}
              onValueChange={(value) => updatePrefs({ silence: value })}
            />
            <ToggleRow
              icon="gesture"
              title="Glide typing"
              body="Swipe through letters to compose a word."
              value={prefs.glide}
              onValueChange={(value) => updatePrefs({ glide: value })}
            />
          </Card>
        </View>
        <View>
          <SectionTitle>Language</SectionTitle>
          <Card style={{ gap: 11 }}>
            <Text style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}>
              The selected keyboard layout and accents work offline. Choose a
              layout:
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {["English (US)", "Español", "Français", "Deutsch"].map(
                (language) => (
                  <Pill
                    key={language}
                    label={language}
                    active={prefs.language === language}
                    onPress={() => updatePrefs({ language })}
                  />
                ),
              )}
            </View>
          </Card>
        </View>
        <View>
          <SectionTitle>Key size</SectionTitle>
          <Card style={{ gap: 10 }}>
            <Text style={{ color: c.muted, fontSize: 12 }}>
              Key height · {prefs.keyHeight} dp
            </Text>
            <View style={{ flexDirection: "row", gap: 8 }}>
              {[44, 48, 52, 56].map((height) => (
                <Pill
                  key={height}
                  label={`${height}`}
                  active={prefs.keyHeight === height}
                  onPress={() => updatePrefs({ keyHeight: height })}
                />
              ))}
            </View>
          </Card>
        </View>
        <Card
          style={{ flexDirection: "row", alignItems: "flex-start", gap: 11 }}
        >
          <MaterialIcons name="lock-outline" color={c.green} size={20} />
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ color: c.text, fontSize: 13, fontWeight: "700" }}>
              Private by design
            </Text>
            <Text style={{ color: c.muted, fontSize: 11, lineHeight: 17 }}>
              Preferences, notes, journal entries, tasks and clipboard are
              stored only on this device. Haven has no account, telemetry, cloud
              sync or network-dependent feature.
            </Text>
          </View>
        </Card>
        <Pressable
          onPress={() =>
            updatePrefs({
              theme: "system",
              numberRow: true,
              haptics: true,
              silence: false,
              glide: true,
              keyHeight: 48,
              language: "English (US)",
            })
          }
        >
          <Text
            style={{
              color: c.muted,
              fontSize: 12,
              textAlign: "center",
              padding: 12,
            }}
          >
            Restore default keyboard settings
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
