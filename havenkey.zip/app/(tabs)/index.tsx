import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  useWindowDimensions,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { KeyboardPreview } from "@/components/haven/KeyboardPreview";
import {
  Card,
  Eyebrow,
  Heading,
  IconBadge,
  SectionTitle,
} from "@/components/haven/ui";
import { TOOLS } from "@/lib/haven/catalog";
import { useHaven, useHavenColors } from "@/lib/haven/store";
export default function HomeScreen() {
  const c = useHavenColors();
  const { clips, prefs, tools } = useHaven();
  const { width } = useWindowDimensions();
  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 34,
          gap: 24,
          maxWidth: 760,
          width: "100%",
          alignSelf: "center",
        }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", gap: 10, alignItems: "center" }}>
            <View
              style={{
                width: 34,
                height: 34,
                borderRadius: 12,
                backgroundColor: c.green,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <MaterialIcons name="keyboard" size={19} color="#fff" />
            </View>
            <Text
              style={{
                color: c.text,
                fontSize: 20,
                fontWeight: "800",
                letterSpacing: -0.5,
              }}
            >
              haven
            </Text>
          </View>
          <View
            style={{
              backgroundColor: c.greenSoft,
              paddingHorizontal: 10,
              paddingVertical: 7,
              borderRadius: 20,
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
            }}
          >
            <View
              style={{
                width: 6,
                height: 6,
                backgroundColor: c.green,
                borderRadius: 4,
              }}
            />
            <Text style={{ color: c.green, fontSize: 10, fontWeight: "700" }}>
              ON DEVICE
            </Text>
          </View>
        </View>
        <View style={{ gap: 13, paddingTop: 2 }}>
          <Eyebrow>YOUR WORDS, YOUR SPACE</Eyebrow>
          <Heading sub="A little more room for the things you want to say.">
            A calmer way to type.
          </Heading>
        </View>
        <Card style={{ padding: 12, backgroundColor: c.raised, gap: 10 }}>
          <View
            style={{
              paddingHorizontal: 5,
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <View>
              <Eyebrow>KEYBOARD PREVIEW</Eyebrow>
              <Text style={{ color: c.text, fontWeight: "600", marginTop: 4 }}>
                {prefs.language} ·{" "}
                {prefs.numberRow ? "number row on" : "number row off"}
              </Text>
            </View>
            <Pressable onPress={() => router.push("/(tabs)/keyboard")}>
              <Text style={{ color: c.green, fontSize: 12, fontWeight: "700" }}>
                Open ↗
              </Text>
            </Pressable>
          </View>
          <KeyboardPreview compact />
        </Card>
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Pressable
            onPress={() => router.push("/(tabs)/keyboard")}
            style={{
              flex: 1,
              borderRadius: 16,
              backgroundColor: c.green,
              paddingVertical: 15,
              flexDirection: "row",
              justifyContent: "center",
              gap: 8,
              alignItems: "center",
            }}
          >
            <MaterialIcons name="keyboard-alt" color="#fff" size={18} />
            <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>
              Try keyboard
            </Text>
          </Pressable>
          <Pressable
            onPress={() => router.push("/(tabs)/settings")}
            style={{
              borderRadius: 16,
              backgroundColor: c.surface,
              borderWidth: 1,
              borderColor: c.line,
              paddingHorizontal: 16,
              justifyContent: "center",
            }}
          >
            <MaterialIcons name="tune" color={c.text} size={20} />
          </Pressable>
        </View>
        <View>
          <SectionTitle>
            Close at hand{" "}
            <Text style={{ color: c.muted, fontWeight: "400", fontSize: 12 }}>
              · {TOOLS.length} small tools
            </Text>
          </SectionTitle>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
            {TOOLS.map((tool, index) => (
              <Pressable
                key={tool.id}
                onPress={() => router.push(`/tool/${tool.id}`)}
                style={({ pressed }) => ({
                  width: width > 620 ? "48.5%" : "48%",
                  flexGrow: 1,
                  backgroundColor: c.surface,
                  borderColor: c.line,
                  borderWidth: 1,
                  borderRadius: 20,
                  padding: 14,
                  gap: 12,
                  opacity: pressed ? 0.78 : 1,
                })}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <IconBadge
                    icon={tool.icon as any}
                    tint={tool.tint}
                    size={38}
                  />
                  <MaterialIcons
                    name="arrow-outward"
                    size={16}
                    color={c.muted}
                  />
                </View>
                <View>
                  <Text
                    style={{ color: c.text, fontWeight: "700", fontSize: 13 }}
                  >
                    {tool.name}
                  </Text>
                  <Text style={{ color: c.muted, fontSize: 11, marginTop: 3 }}>
                    {tool.id === "harmony"
                      ? "KJV · 4 Gospel views"
                      : `${tools[tool.id]?.length ?? 0} saved · offline`}
                  </Text>
                </View>
              </Pressable>
            ))}
          </View>
        </View>
        <Card
          style={{
            flexDirection: "row",
            gap: 12,
            alignItems: "center",
            padding: 14,
          }}
        >
          <IconBadge icon="shield" tint="green" size={40} />
          <View style={{ flex: 1, gap: 3 }}>
            <Text style={{ color: c.text, fontSize: 13, fontWeight: "700" }}>
              Made for offline days.
            </Text>
            <Text style={{ color: c.muted, fontSize: 11, lineHeight: 16 }}>
              Your clips, notes and entries stay on this device. No network
              needed.
            </Text>
          </View>
        </Card>
        <Text style={{ color: c.muted, textAlign: "center", fontSize: 10 }}>
          CLIPS · {clips.length} SAVED ·{" "}
          {prefs.silence ? "SILENT" : "HAPTICS ON"}
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}
