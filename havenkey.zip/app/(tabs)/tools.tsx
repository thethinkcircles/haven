import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import {
  Pressable,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Card, Eyebrow, Heading, IconBadge } from "@/components/haven/ui";
import { TOOLS } from "@/lib/haven/catalog";
import { useHaven, useHavenColors } from "@/lib/haven/store";
export default function ToolsScreen() {
  const c = useHavenColors();
  const { tools } = useHaven();
  const { width } = useWindowDimensions();
  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 34,
          gap: 20,
          maxWidth: 760,
          width: "100%",
          alignSelf: "center",
        }}
      >
        <View style={{ gap: 8 }}>
          <Eyebrow>SMALL THINGS, WELL KEPT</Eyebrow>
          <Heading sub="A few thoughtful tools, right where you type.">
            Your toolkit.
          </Heading>
        </View>
        <Card
          style={{
            backgroundColor: c.greenSoft,
            borderColor: "transparent",
            flexDirection: "row",
            gap: 12,
            alignItems: "center",
          }}
        >
          <IconBadge icon="offline-bolt" />
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.text, fontSize: 14, fontWeight: "700" }}>
              Works without a connection
            </Text>
            <Text
              style={{
                color: c.muted,
                fontSize: 12,
                marginTop: 3,
                lineHeight: 18,
              }}
            >
              Your notes, reflections and practice stay saved on this device.
            </Text>
          </View>
        </Card>
        <View style={{ gap: 10 }}>
          {TOOLS.map((tool, index) => (
            <Pressable
              key={tool.id}
              onPress={() => router.push(`/tool/${tool.id}`)}
              style={({ pressed }) => ({ opacity: pressed ? 0.76 : 1 })}
            >
              <Card
                style={{
                  padding: 14,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 13,
                }}
              >
                <IconBadge icon={tool.icon as any} tint={tool.tint} />
                <View style={{ flex: 1, gap: 3 }}>
                  <Text
                    style={{ color: c.text, fontSize: 15, fontWeight: "700" }}
                  >
                    {tool.name}
                  </Text>
                  <Text style={{ color: c.muted, fontSize: 12 }}>
                    {tool.subtitle}
                  </Text>
                </View>
                <Text style={{ color: c.muted, fontSize: 11 }}>
                  {tools[tool.id]?.length ?? 0}
                </Text>
                <MaterialIcons name="chevron-right" size={21} color={c.muted} />
              </Card>
            </Pressable>
          ))}
        </View>
        <Text style={{ color: c.muted, fontSize: 10, textAlign: "center" }}>
          No account · No cloud sync · Stored locally
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}
