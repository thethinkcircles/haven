import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Pressable, ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { KeyboardPreview } from "@/components/haven/KeyboardPreview";
import { Card, Eyebrow, Heading, SectionTitle } from "@/components/haven/ui";
import { useHaven, useHavenColors } from "@/lib/haven/store";

const keyboardFeatures = [
  {
    icon: "gesture",
    title: "Glide & move",
    body: "The Android keyboard traces across its three letter rows for local word candidates. The preview spacebar gesture edits preview text.",
  },
  {
    icon: "touch-app",
    title: "Long-press accents",
    body: "Hold a letter to reveal accented variations without leaving the keyboard.",
  },
  {
    icon: "emoji-emotions",
    title: "Emoji & symbols",
    body: "Switch between emoji, common symbols and advanced math/special characters.",
  },
  {
    icon: "edit",
    title: "Text editor",
    body: "Use cursor arrows, selection, select all, cut/copy/paste and undo/redo from the native editing toolbar.",
  },
];

export default function KeyboardScreen() {
  const c = useHavenColors();
  const { prefs, clips, removeClip, togglePin } = useHaven();

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 32,
          gap: 23,
          maxWidth: 760,
          width: "100%",
          alignSelf: "center",
        }}
      >
        <View style={{ gap: 8 }}>
          <Eyebrow>HAVE A LITTLE PLAY</Eyebrow>
          <Heading sub="Explore every layer. The companion tools work without internet.">
            Your keyboard.
          </Heading>
        </View>

        <KeyboardPreview />

        <Card
          style={{
            backgroundColor: c.greenSoft,
            borderColor: "transparent",
            flexDirection: "row",
            gap: 10,
            alignItems: "flex-start",
          }}
        >
          <MaterialIcons name="info-outline" color={c.green} size={20} />
          <View style={{ flex: 1, gap: 5 }}>
            <Text style={{ color: c.text, fontSize: 13, fontWeight: "700" }}>
              System-wide typing requires the custom Android build
            </Text>
            <Text style={{ color: c.muted, fontSize: 11, lineHeight: 17 }}>
              Expo Go shows the interactive preview, not a system input method.
              After the Android build is installed, enable Haven in Android
              Settings → System → Keyboard → On-screen keyboard → Manage
              keyboards. Some devices place this under General management →
              Keyboard list and default. Switch to Haven from the keyboard
              selector, then open Haven Keyboard settings to control its number
              row, language, size, haptics, silence and glide options.
            </Text>
            <Text style={{ color: c.muted, fontSize: 11, lineHeight: 17 }}>
              The controls in the app’s Settings customize the preview only;
              Android’s Haven Keyboard settings control the installed keyboard.
            </Text>
          </View>
        </Card>

        <View style={{ gap: 10 }}>
          <SectionTitle>What’s in the keys</SectionTitle>
          {keyboardFeatures.map((item) => (
            <View
              key={item.title}
              style={{
                flexDirection: "row",
                gap: 12,
                backgroundColor: c.surface,
                borderRadius: 16,
                padding: 13,
                borderColor: c.line,
                borderWidth: 1,
              }}
            >
              <MaterialIcons
                name={item.icon as any}
                color={c.green}
                size={20}
              />
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: c.text, fontSize: 13, fontWeight: "700" }}
                >
                  {item.title}
                </Text>
                <Text
                  style={{
                    color: c.muted,
                    fontSize: 11,
                    marginTop: 2,
                    lineHeight: 16,
                  }}
                >
                  {item.body}
                </Text>
              </View>
            </View>
          ))}
        </View>

        <View>
          <SectionTitle trailing="Saved only on this device">
            Recent clipboard
          </SectionTitle>
          {clips.length === 0 ? (
            <Card>
              <Text style={{ color: c.muted, fontSize: 13 }}>
                Tap “Save text to clipboard” in the preview. Your private clips
                live here.
              </Text>
            </Card>
          ) : (
            <View style={{ gap: 8 }}>
              {clips.map((item) => (
                <Card
                  key={item.id}
                  style={{
                    padding: 13,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 10,
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{ color: c.text, fontSize: 13 }}
                      numberOfLines={2}
                    >
                      {item.text}
                    </Text>
                    <Text
                      style={{ color: c.muted, fontSize: 10, marginTop: 4 }}
                    >
                      {new Date(item.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                  <Pressable onPress={() => togglePin(item.id)}>
                    <MaterialIcons
                      name="push-pin"
                      size={17}
                      color={item.pinned ? c.green : c.muted}
                    />
                  </Pressable>
                  <Pressable onPress={() => removeClip(item.id)}>
                    <MaterialIcons name="close" size={18} color={c.muted} />
                  </Pressable>
                </Card>
              ))}
            </View>
          )}
        </View>

        <Text
          style={{
            color: c.muted,
            fontSize: 11,
            lineHeight: 17,
            textAlign: "center",
          }}
        >
          No Haven network calls or learned typing history. The local suggestion
          list is small and independent of LeanType’s GPL-3.0-only engine.
          Password fields disable glide, suggestions and clipboard capture.
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}
