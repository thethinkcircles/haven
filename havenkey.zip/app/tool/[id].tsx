import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import {
  ActionButton,
  Card,
  Eyebrow,
  Heading,
  IconBadge,
  Pill,
  SectionTitle,
} from "@/components/haven/ui";
import { BibleReader } from "@/components/haven/BibleReader";
import { CalendarTool } from "@/components/haven/CalendarTool";
import { CalculatorTool } from "@/components/haven/CalculatorTool";
import { GospelHarmony } from "@/components/haven/GospelHarmony";
import { PrayerTool } from "@/components/haven/PrayerTool";
import { ToolCustomizePanel } from "@/components/haven/ToolCustomizePanel";
import { TOOLS } from "@/lib/haven/catalog";
import { useHaven, useHavenColors, type HavenRecord } from "@/lib/haven/store";
function LocalInput({
  tool,
  onSave,
}: {
  tool: string;
  onSave: (title: string, body: string) => void;
}) {
  const c = useHavenColors();
  const { toolPrefs } = useHaven();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [selectedMeal, setSelectedMeal] = useState("");
  const meal = toolPrefs.plate?.mealLabels;
  const placeholder =
    tool === "plate"
      ? meal === "Custom"
        ? "Meal name"
        : "Breakfast · Lunch · Dinner"
      : tool === "notes"
        ? "Give this note a title"
        : tool === "memory"
          ? "Question or phrase to remember"
          : tool === "journal"
            ? "How did today feel?"
            : tool === "todo"
              ? "What would you like to do?"
              : tool === "followup"
                ? "What needs a follow-up?"
                : tool === "exercise"
                  ? "Movement or activity"
                  : tool === "sleep"
                    ? `Bedtime · ${toolPrefs.sleep?.clock ?? "12-hour"} time`
                    : "A title";
  const bodyHint =
    tool === "plate"
      ? `Portions: ${toolPrefs.plate?.serving ?? "Simple portions"} · add a note if you like`
      : tool === "memory"
        ? "Add the answer or hint here."
        : tool === "journal"
          ? toolPrefs.journal?.prompts === "Off"
            ? "Add a private note."
            : "What is one thing you want to remember from today?"
          : tool === "exercise"
            ? `Add your duration in ${toolPrefs.exercise?.unit ?? "Minutes"}, or a short note.`
            : tool === "sleep"
              ? "Add wake time after a comma (e.g. 10:30 pm, 6:30 am)."
              : "Add a thought or detail (optional).";
  return (
    <Card
      style={{
        gap: 10,
        backgroundColor:
          tool === "notes"
            ? toolPrefs.notes?.noteTint === "Peach"
              ? c.peach
              : toolPrefs.notes?.noteTint === "Lavender"
                ? c.lavender
                : c.greenSoft
            : c.surface,
      }}
    >
      <TextInput
        value={title}
        onChangeText={setTitle}
        placeholder={placeholder}
        placeholderTextColor={c.muted}
        style={{
          backgroundColor: c.raised,
          color: c.text,
          borderRadius: 13,
          padding: 12,
          fontSize: 14,
        }}
      />
      {tool === "plate" && meal !== "Custom" ? (
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
          {["Breakfast", "Lunch", "Dinner", "Snack"].map((label) => (
            <Pill
              key={label}
              label={label}
              active={selectedMeal === label}
              onPress={() => setSelectedMeal(label)}
            />
          ))}
        </View>
      ) : null}
      <TextInput
        value={body}
        onChangeText={setBody}
        placeholder={bodyHint}
        placeholderTextColor={c.muted}
        multiline
        style={{
          backgroundColor: c.raised,
          color: c.text,
          borderRadius: 13,
          padding: 12,
          minHeight: 66,
          textAlignVertical: "top",
          fontSize: 13,
        }}
      />
      <ActionButton
        label={
          tool === "todo"
            ? "Add task"
            : tool === "memory"
              ? "Add memory card"
              : tool === "plate"
                ? "Save meal"
                : tool === "exercise"
                  ? "Log activity"
                  : tool === "sleep"
                    ? "Save sleep log"
                    : tool === "journal"
                      ? "Save reflection"
                      : tool === "notes"
                        ? "Save note"
                        : tool === "followup"
                          ? "Add follow-up"
                          : "Save entry"
        }
        icon="add"
        onPress={() => {
          if (title.trim() || body.trim()) {
            onSave(
              title.trim() ||
                (tool === "plate" ? selectedMeal || "Meal" : placeholder),
              body.trim(),
            );
            setTitle("");
            setBody("");
            setSelectedMeal("");
          }
        }}
      />
    </Card>
  );
}
export default function ToolDetailScreen() {
  const params = useLocalSearchParams<{ id: string }>();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const tool = TOOLS.find((item) => item.id === id);
  const c = useHavenColors();
  const { tools, addRecord, toggleRecord, removeRecord, toolPrefs } =
    useHaven();
  const [showAnswer, setShowAnswer] = useState<Record<string, boolean>>({});
  const records: HavenRecord[] = tools[id ?? ""] ?? [];
  const visibleRecords = useMemo(() => {
    let result = [...records];
    const prefs = toolPrefs[id ?? ""] ?? {};
    if (prefs.sort === "Alphabetical")
      result.sort((a, b) => a.title.localeCompare(b.title));
    if (prefs.sort === "Oldest") result.reverse();
    if ((id === "todo" || id === "followup") && prefs.completed === "Hide")
      result = result.filter((item) => !item.done);
    if (id === "prayer" && prefs.answered === "Hide")
      result = result.filter((item) => !item.done);
    return result;
  }, [records, id, toolPrefs]);
  if (!tool)
    return (
      <ScreenContainer>
        <View style={{ padding: 24, gap: 14 }}>
          <Text style={{ color: c.text, fontSize: 22, fontWeight: "700" }}>
            This tool isn’t here.
          </Text>
          <ActionButton label="Back to tools" onPress={() => router.back()} />
        </View>
      </ScreenContainer>
    );
  let content;
  if (id === "bible") content = <BibleReader />;
  else if (id === "harmony") content = <GospelHarmony />;
  else if (id === "calendar") content = <CalendarTool />;
  else if (id === "prayer") content = <PrayerTool records={visibleRecords} />;
  else if (id === "discount" || id === "calculator")
    content = <CalculatorTool kind={id} />;
  else
    content = (
      <View style={{ gap: 13 }}>
        <Card
          style={{
            backgroundColor: c.greenSoft,
            borderColor: "transparent",
            flexDirection: "row",
            gap: 10,
            alignItems: "center",
          }}
        >
          <MaterialIcons name="offline-bolt" size={19} color={c.green} />
          <Text
            style={{ color: c.text, fontSize: 12, flex: 1, lineHeight: 17 }}
          >
            No account. Your {tool.name.toLowerCase()} and its preferences stay
            on this device.
          </Text>
        </Card>
        {id === "memory" && visibleRecords.length > 0 ? (
          <Card
            style={{
              gap: 10,
              backgroundColor: c.lavender,
              borderColor: "transparent",
            }}
          >
            <Eyebrow>
              QUICK REVIEW · GOAL {toolPrefs.memory?.dailyGoal ?? "3"}/DAY ·{" "}
              {toolPrefs.memory?.reviewDirection ?? "Prompt first"}
            </Eyebrow>
            {visibleRecords.slice(0, 1).map((record) => (
              <View key={record.id} style={{ gap: 10 }}>
                <Text
                  style={{ color: c.text, fontSize: 16, fontWeight: "700" }}
                >
                  {toolPrefs.memory?.reviewDirection === "Answer first"
                    ? record.body || record.title
                    : record.title}
                </Text>
                <Text style={{ color: c.muted, fontSize: 13 }}>
                  {showAnswer[record.id]
                    ? record.body || "No answer added yet."
                    : "Take a moment to recall it."}
                </Text>
                <ActionButton
                  label={
                    showAnswer[record.id] ? "Hide answer" : "Reveal answer"
                  }
                  icon="visibility"
                  secondary
                  onPress={() =>
                    setShowAnswer((prev) => ({
                      ...prev,
                      [record.id]: !prev[record.id],
                    }))
                  }
                />
              </View>
            ))}
          </Card>
        ) : null}
        {id === "journal" &&
        toolPrefs.journal?.prompts !== "Off" &&
        (toolPrefs.journal?.view ?? "Daily") === "Daily" ? (
          <Text style={{ color: c.green, fontSize: 12 }}>
            Today’s prompt: What is one thing you want to remember?
          </Text>
        ) : null}
        {id === "exercise" ? (
          <Text style={{ color: c.muted, fontSize: 11 }}>
            Weekly target · {toolPrefs.exercise?.weeklyGoal ?? "3"} sessions ·
            units in {toolPrefs.exercise?.unit ?? "Minutes"}
          </Text>
        ) : null}
        {id === "sleep" ? (
          <Text style={{ color: c.muted, fontSize: 11 }}>
            Rest goal · {toolPrefs.sleep?.goal ?? "8 h"} ·{" "}
            {toolPrefs.sleep?.clock ?? "12-hour"} clock
          </Text>
        ) : null}
        <LocalInput
          key={id}
          tool={id!}
          onSave={(title, body) => addRecord(id!, title, body)}
        />
        <View style={{ gap: 9 }}>
          <SectionTitle trailing={`· ${visibleRecords.length}`}>
            {id === "memory"
              ? "Cards to remember"
              : id === "plate"
                ? "Recent plates"
                : id === "notes"
                  ? "Your notes"
                  : id === "journal"
                    ? "Journal entries"
                    : id === "todo"
                      ? "To Do"
                      : id === "followup"
                        ? "Follow-ups"
                        : id === "exercise"
                          ? "Movement log"
                          : "Sleep log"}
          </SectionTitle>
          {visibleRecords.length === 0 ? (
            <Card>
              <Text style={{ color: c.muted, fontSize: 12 }}>
                Nothing saved yet. Add a small first entry above.
              </Text>
            </Card>
          ) : (
            visibleRecords.map((record) => (
              <Card
                key={record.id}
                style={{
                  padding: 14,
                  flexDirection: "row",
                  alignItems: "flex-start",
                  gap: 10,
                }}
              >
                {id === "todo" || id === "followup" ? (
                  <Pressable onPress={() => toggleRecord(id!, record.id)}>
                    <MaterialIcons
                      name={
                        record.done ? "check-circle" : "radio-button-unchecked"
                      }
                      size={21}
                      color={record.done ? c.green : c.muted}
                    />
                  </Pressable>
                ) : null}
                <View style={{ flex: 1, gap: 5 }}>
                  <Text
                    style={{
                      color: record.done ? c.muted : c.text,
                      fontSize: 14,
                      fontWeight: "700",
                      textDecorationLine: record.done ? "line-through" : "none",
                    }}
                  >
                    {record.title}
                  </Text>
                  {record.body ? (
                    <Text
                      style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}
                    >
                      {record.body}
                    </Text>
                  ) : null}
                  <Text style={{ color: c.muted, fontSize: 10 }}>
                    {new Date(record.createdAt).toLocaleDateString()}
                  </Text>
                </View>
                <Pressable onPress={() => removeRecord(id!, record.id)}>
                  <MaterialIcons name="close" size={17} color={c.muted} />
                </Pressable>
              </Card>
            ))
          )}
        </View>
      </View>
    );
  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{
          padding: 20,
          paddingBottom: 36,
          gap: 18,
          maxWidth: 740,
          width: "100%",
          alignSelf: "center",
        }}
      >
        <Pressable
          onPress={() => router.back()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            alignSelf: "flex-start",
            paddingVertical: 4,
          }}
        >
          <MaterialIcons name="arrow-back" size={18} color={c.green} />
          <Text style={{ color: c.green, fontSize: 13, fontWeight: "700" }}>
            Your tools
          </Text>
        </Pressable>
        <View style={{ flexDirection: "row", gap: 13, alignItems: "center" }}>
          <IconBadge icon={tool.icon as any} tint={tool.tint} size={52} />
          <View style={{ flex: 1, gap: 3 }}>
            <Eyebrow>ON DEVICE · OFFLINE</Eyebrow>
            <Heading>{tool.name}</Heading>
          </View>
        </View>
        <ToolCustomizePanel tool={id!} />
        {content}
      </ScrollView>
    </ScreenContainer>
  );
}
