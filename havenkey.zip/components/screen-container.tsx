import { View, type ViewProps } from "react-native";
import { SafeAreaView, type Edge } from "react-native-safe-area-context";
import { cn } from "@/lib/utils";
import { useHavenColors } from "@/lib/haven/store";
export interface ScreenContainerProps extends ViewProps {
  edges?: Edge[];
  className?: string;
  containerClassName?: string;
  safeAreaClassName?: string;
}
export function ScreenContainer({
  children,
  edges = ["top", "left", "right"],
  className,
  containerClassName,
  safeAreaClassName,
  style,
  ...props
}: ScreenContainerProps) {
  const colors = useHavenColors();
  return (
    <View
      className={cn("flex-1", "bg-background", containerClassName)}
      style={{ backgroundColor: colors.bg }}
      {...props}
    >
      <SafeAreaView
        edges={edges}
        className={cn("flex-1", safeAreaClassName)}
        style={[{ backgroundColor: colors.bg }, style]}
      >
        <View
          className={cn("flex-1", className)}
          style={{ backgroundColor: colors.bg }}
        >
          {children}
        </View>
      </SafeAreaView>
    </View>
  );
}
