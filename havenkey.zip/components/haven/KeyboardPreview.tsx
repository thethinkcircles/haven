import { useMemo, useState } from "react";
import { router } from "expo-router";
import {
  PanResponder,
  Pressable,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import * as Haptics from "expo-haptics";
import { TOOLS } from "@/lib/haven/catalog";
import { useHaven, useHavenColors, type KeyLayer } from "@/lib/haven/store";
const rows = {
  numbers: ["1234567890", "@#$%&-*+()", "!?\"':;/_"],
  symbols: ["~`|•√π÷×¶∆", "£¢€¥^°={}", "\\<>©®™✓"],
};
const languageRows: Record<string, string[]> = {
  "English (US)": ["qwertyuiop", "asdfghjkl", "zxcvbnm"],
  Español: ["qwertyuiop", "asdfghjklñ", "zxcvbnm"],
  Français: ["azertyuiop", "qsdfghjklm", "wxcvbn"],
  Deutsch: ["qwertzuiop", "asdfghjklö", "yxcvbnm"],
};
const alternatives: Record<string, string[]> = {
  a: ["á", "à", "â", "ä", "æ", "ã", "å"],
  e: ["é", "è", "ê", "ë"],
  i: ["í", "ì", "î", "ï"],
  o: ["ó", "ò", "ô", "ö", "œ", "õ"],
  u: ["ú", "ù", "û", "ü"],
  n: ["ñ"],
  c: ["ç"],
  s: ["ß", "š"],
  y: ["ý", "ÿ"],
  "?": ["¿"],
  "!": ["¡"],
  $: ["€", "£", "¥"],
};
const emojiSet = [
  "😀",
  "😂",
  "🥹",
  "😍",
  "🥰",
  "😊",
  "🙏",
  "❤️",
  "✨",
  "🔥",
  "🎉",
  "👍",
  "🤔",
  "😎",
  "💛",
  "🌿",
  "🕊️",
  "☀️",
  "💐",
  "🫶",
  "🙂",
  "💡",
  "🤍",
  "📖",
  "🙌",
];
export function KeyboardPreview({
  compact = false,
  onText,
}: {
  compact?: boolean;
  onText?: (value: string) => void;
}) {
  const c = useHavenColors();
  const { prefs, updatePrefs, clips, addClip, togglePin, removeClip } =
    useHaven();
  const { width } = useWindowDimensions();
  const [layer, setLayer] = useState<KeyLayer>("letters");
  const [shift, setShift] = useState(false);
  const [value, setValue] = useState("");
  const [cursor, setCursor] = useState(0);
  const [selection, setSelection] = useState<[number, number] | null>(null);
  const [history, setHistory] = useState<
    Array<{ value: string; cursor: number; selection: [number, number] | null }>
  >([]);
  const [redoHistory, setRedoHistory] = useState<
    Array<{ value: string; cursor: number; selection: [number, number] | null }>
  >([]);
  const [popup, setPopup] = useState("");
  const [emojiFilter, setEmojiFilter] = useState("");
  const keyboardRows =
    layer === "letters"
      ? (languageRows[prefs.language] ?? languageRows["English (US)"])
      : layer === "numbers" || layer === "symbols"
        ? rows[layer]
        : [];
  const keyHeight = compact
    ? 40
    : Math.max(40, Math.min(prefs.keyHeight, width > 740 ? 62 : 54));
  const visibleEmoji = useMemo(
    () =>
      emojiSet.filter((emoji) => !emojiFilter || emoji.includes(emojiFilter)),
    [emojiFilter],
  );
  const applyEdit = (next: string, at: number) => {
    setHistory((prev) => [...prev, { value, cursor, selection }].slice(-20));
    setRedoHistory([]);
    setValue(next);
    setCursor(Math.max(0, Math.min(at, next.length)));
    setSelection(null);
  };
  const addText = (text: string) => {
    if (prefs.haptics) {
      try {
        void Haptics.selectionAsync();
      } catch {}
    }
    const start = selection ? Math.min(...selection) : cursor;
    const end = selection ? Math.max(...selection) : cursor;
    applyEdit(
      value.slice(0, start) + text + value.slice(end),
      start + text.length,
    );
    onText?.(text);
  };
  const deleteBackward = () => {
    const start = selection ? Math.min(...selection) : Math.max(0, cursor - 1);
    const end = selection ? Math.max(...selection) : cursor;
    if (start === end) return;
    applyEdit(value.slice(0, start) + value.slice(end), start);
  };
  const undo = () => {
    const prior = history[history.length - 1];
    if (!prior) return;
    setRedoHistory((prev) =>
      [...prev, { value, cursor, selection }].slice(-20),
    );
    setHistory((prev) => prev.slice(0, -1));
    setValue(prior.value);
    setCursor(prior.cursor);
    setSelection(prior.selection);
  };
  const redo = () => {
    const next = redoHistory[redoHistory.length - 1];
    if (!next) return;
    setHistory((prev) => [...prev, { value, cursor, selection }].slice(-20));
    setRedoHistory((prev) => prev.slice(0, -1));
    setValue(next.value);
    setCursor(next.cursor);
    setSelection(next.selection);
  };
  const pan = PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 35,
    onPanResponderRelease: (_, g) => {
      if (Math.abs(g.dx) > 35) {
        if (g.dx < 0) {
          const before = value.slice(0, cursor).replace(/\S+\s*$/g, "");
          applyEdit(before + value.slice(cursor), before.length);
        } else addText(" ");
      }
    },
  });
  const keyStyle = (special = false) => ({
    height: keyHeight,
    flex: special ? 1.45 : 1,
    borderRadius: 11,
    backgroundColor: special ? c.raised : c.surface,
    borderWidth: 1,
    borderColor: c.line,
    alignItems: "center" as const,
    justifyContent: "center" as const,
    marginHorizontal: 2,
    shadowColor: "#000",
    shadowOpacity: 0.045,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  });
  return (
    <View
      style={{
        backgroundColor: c.raised,
        borderRadius: 24,
        padding: compact ? 9 : 12,
        gap: 8,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          minHeight: 34,
        }}
      >
        <Text
          numberOfLines={1}
          style={{ color: c.muted, fontSize: 12, flex: 1 }}
        >
          {value ? (
            selection ? (
              <>
                <Text>{value.slice(0, Math.min(...selection))}</Text>
                <Text style={{ backgroundColor: c.greenSoft }}>
                  {value.slice(Math.min(...selection), Math.max(...selection))}
                </Text>
                <Text>{value.slice(Math.max(...selection))}</Text>
              </>
            ) : (
              <>
                <Text>{value.slice(0, cursor)}</Text>
                <Text style={{ color: c.green, fontWeight: "800" }}>│</Text>
                <Text>{value.slice(cursor)}</Text>
              </>
            )
          ) : (
            "Try typing something..."
          )}
        </Text>
        <View style={{ flexDirection: "row", gap: 2 }}>
          {[
            { id: "letters", label: "⌨" },
            { id: "numbers", label: "?123" },
            { id: "symbols", label: "=\\<" },
            { id: "emoji", label: "☺" },
            { id: "clipboard", label: "▤" },
            { id: "editor", label: "Edit" },
          ].map((item) => (
            <Pressable
              key={item.id}
              onPress={() => setLayer(item.id as KeyLayer)}
              style={{
                backgroundColor: layer === item.id ? c.green : "transparent",
                borderRadius: 9,
                paddingHorizontal: 7,
                paddingVertical: 6,
              }}
            >
              <Text
                style={{
                  color: layer === item.id ? "#fff" : c.muted,
                  fontWeight: "700",
                  fontSize: 11,
                }}
              >
                {item.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 4 }}
      >
        {TOOLS.map((tool) => (
          <Pressable
            key={tool.id}
            onPress={() => router.push(`/tool/${tool.id}`)}
            style={{
              backgroundColor: c.surface,
              borderRadius: 12,
              paddingHorizontal: 9,
              paddingVertical: 7,
            }}
          >
            <Text style={{ color: c.text, fontSize: 10, fontWeight: "600" }}>
              {tool.name}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
      {layer === "editor" ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 5 }}
        >
          {[
            [
              "←",
              () => {
                setCursor(Math.max(0, cursor - 1));
                setSelection(null);
              },
            ],
            [
              "→",
              () => {
                setCursor(Math.min(value.length, cursor + 1));
                setSelection(null);
              },
            ],
            ["Select all", () => setSelection([0, value.length])],
            [
              "Cut",
              () => {
                if (selection) {
                  addClip(
                    value.slice(Math.min(...selection), Math.max(...selection)),
                  );
                  deleteBackward();
                }
              },
            ],
            [
              "Copy",
              () => {
                if (selection)
                  addClip(
                    value.slice(Math.min(...selection), Math.max(...selection)),
                  );
              },
            ],
            [
              "Paste",
              () => {
                if (clips[0]) addText(clips[0].text);
              },
            ],
            ["Undo", undo],
            ["Redo", redo],
          ].map(([label, action]) => (
            <Pressable
              key={String(label)}
              onPress={action as () => void}
              style={{
                backgroundColor: c.surface,
                borderRadius: 10,
                paddingHorizontal: 10,
                paddingVertical: 8,
              }}
            >
              <Text style={{ color: c.text, fontSize: 11, fontWeight: "600" }}>
                {String(label)}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      ) : null}
      {layer === "emoji" ? (
        <View style={{ gap: 7 }}>
          <Pressable
            onPress={() => setEmojiFilter(emojiFilter ? "" : "✨")}
            style={{ backgroundColor: c.surface, borderRadius: 10, padding: 9 }}
          >
            <Text style={{ color: c.text, fontSize: 12 }}>
              {emojiFilter
                ? "Clear emoji filter"
                : "Search emoji · tap to filter ✨"}
            </Text>
          </Pressable>
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "space-between",
            }}
          >
            {visibleEmoji.map((emoji, i) => (
              <Pressable
                key={`${emoji}${i}`}
                onPress={() => addText(emoji)}
                style={{
                  width: "19%",
                  paddingVertical: 8,
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 24 }}>{emoji}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      ) : layer === "clipboard" ? (
        <ScrollView
          style={{ maxHeight: 190 }}
          contentContainerStyle={{ gap: 7 }}
          nestedScrollEnabled
        >
          {clips.length ? (
            clips.map((clip) => (
              <View
                key={clip.id}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  backgroundColor: c.surface,
                  padding: 9,
                  borderRadius: 12,
                  gap: 8,
                }}
              >
                <Pressable
                  onPress={() => addText(clip.text)}
                  style={{ flex: 1 }}
                >
                  <Text
                    numberOfLines={2}
                    style={{ color: c.text, fontSize: 12 }}
                  >
                    {clip.text}
                  </Text>
                </Pressable>
                <Pressable onPress={() => togglePin(clip.id)}>
                  <Text style={{ color: c.green }}>
                    {clip.pinned ? "★" : "☆"}
                  </Text>
                </Pressable>
                <Pressable onPress={() => removeClip(clip.id)}>
                  <Text style={{ color: c.muted }}>×</Text>
                </Pressable>
              </View>
            ))
          ) : (
            <Text style={{ color: c.muted, padding: 12 }}>
              Clips you save will stay here, on this device.
            </Text>
          )}
        </ScrollView>
      ) : (
        <>
          {layer === "letters" && prefs.numberRow ? (
            <View style={{ flexDirection: "row", height: keyHeight * 0.72 }}>
              {[..."1234567890"].map((digit) => (
                <Pressable
                  key={digit}
                  onPress={() => addText(digit)}
                  style={[keyStyle(), { height: keyHeight * 0.72 }]}
                >
                  <Text style={{ color: c.muted, fontSize: 11 }}>{digit}</Text>
                </Pressable>
              ))}
            </View>
          ) : null}
          {keyboardRows.map((row, rowIndex) => (
            <View
              key={`${layer}-${rowIndex}`}
              style={{
                flexDirection: "row",
                justifyContent: "center",
                height: keyHeight,
                alignItems: "stretch",
              }}
            >
              {rowIndex === 2 && layer === "letters" ? (
                <Pressable
                  onPress={() => setShift(!shift)}
                  style={keyStyle(true)}
                >
                  <Text style={{ color: c.text, fontSize: 15 }}>⇧</Text>
                </Pressable>
              ) : null}
              {[...row].map((char, index) => {
                const label = shift ? char.toUpperCase() : char;
                return (
                  <Pressable
                    key={`${rowIndex}-${index}`}
                    delayLongPress={220}
                    onPress={() => addText(label)}
                    onLongPress={() => setPopup(char)}
                    style={keyStyle()}
                  >
                    <Text
                      style={{
                        color: c.text,
                        fontSize: compact ? 16 : 19,
                        fontWeight: "500",
                      }}
                    >
                      {label}
                    </Text>
                    {alternatives[char] ? (
                      <Text
                        style={{
                          position: "absolute",
                          top: 1,
                          right: 4,
                          fontSize: 7,
                          color: c.muted,
                        }}
                      >
                        {alternatives[char][0]}
                      </Text>
                    ) : null}
                  </Pressable>
                );
              })}
              {rowIndex === 2 && layer === "letters" ? (
                <Pressable
                  onPress={deleteBackward}
                  onLongPress={() => applyEdit("", 0)}
                  style={keyStyle(true)}
                >
                  <Text style={{ color: c.text, fontSize: 16 }}>⌫</Text>
                </Pressable>
              ) : null}
            </View>
          ))}
          <View style={{ flexDirection: "row", gap: 3, height: keyHeight }}>
            <Pressable
              onPress={() =>
                setLayer(layer === "letters" ? "numbers" : "letters")
              }
              style={keyStyle(true)}
            >
              <Text style={{ color: c.text, fontSize: 11 }}>
                {layer === "letters" ? "?123" : "ABC"}
              </Text>
            </Pressable>
            <Pressable onPress={() => addText(",")} style={keyStyle()}>
              <Text style={{ color: c.text, fontSize: 17 }}>,</Text>
            </Pressable>
            <Pressable
              onPress={() => addText(" ")}
              style={[keyStyle(), { flex: 5 }]}
              {...pan.panHandlers}
            >
              <Text style={{ color: c.muted, fontSize: 11 }}>
                English · swipe to edit
              </Text>
            </Pressable>
            <Pressable onPress={() => addText(".")} style={keyStyle()}>
              <Text style={{ color: c.text, fontSize: 17 }}>.</Text>
            </Pressable>
            <Pressable
              onPress={() => addText("\n")}
              style={[keyStyle(true), { backgroundColor: c.green }]}
            >
              <Text style={{ color: "#fff", fontSize: 15 }}>↵</Text>
            </Pressable>
          </View>
        </>
      )}
      {popup ? (
        <View
          style={{
            position: "absolute",
            top: 47,
            left: "15%",
            right: "15%",
            backgroundColor: c.text,
            borderRadius: 14,
            padding: 9,
            flexDirection: "row",
            justifyContent: "space-around",
            zIndex: 10,
            elevation: 4,
          }}
        >
          {[popup, ...(alternatives[popup] ?? [])].map((char, i) => (
            <Pressable
              key={`${char}${i}`}
              onPress={() => {
                addText(char);
                setPopup("");
              }}
            >
              <Text style={{ color: c.bg, fontSize: 20 }}>{char}</Text>
            </Pressable>
          ))}
          <Pressable onPress={() => setPopup("")}>
            <Text style={{ color: c.green }}>×</Text>
          </Pressable>
        </View>
      ) : null}
      {!compact ? (
        <Pressable
          onPress={() => addClip(value)}
          style={{ alignSelf: "flex-end", paddingTop: 2 }}
        >
          <Text style={{ color: c.muted, fontSize: 10 }}>
            Save text to clipboard · {prefs.silence ? "silent" : "haptics on"}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}
