import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { Text, TextInput, View } from "react-native";
import { ActionButton, Card, Pill } from "@/components/haven/ui";
import { calculateDiscount, evaluateScientific } from "@/lib/haven/calculator";
import { useHaven, useHavenColors } from "@/lib/haven/store";
const currencies: Record<string, string> = {
  "$ USD": "$",
  "€ EUR": "€",
  "£ GBP": "£",
};
export function CalculatorTool({ kind }: { kind: "discount" | "calculator" }) {
  const c = useHavenColors();
  const { toolPrefs } = useHaven();
  const isDiscount = kind === "discount";
  const [price, setPrice] = useState("49.99");
  const [discount, setDiscount] = useState("20");
  const [tax, setTax] = useState("0");
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const currency = currencies[toolPrefs.discount?.currency ?? "$ USD"] ?? "$";
  const degrees = (toolPrefs.calculator?.angle ?? "Degrees") === "Degrees";
  const precision = Number(
    (toolPrefs.calculator?.precision ?? "8 decimals").split(" ")[0],
  );
  const discountResult = () => {
    try {
      const res = calculateDiscount(
        Number(price),
        Number(discount),
        toolPrefs.discount?.tax === "Add tax" ? Number(tax) : 0,
      );
      setResult(
        `${currency}${res.total.toFixed(2)} total · ${currency}${res.savings.toFixed(2)} saved`,
      );
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Check these values.");
    }
  };
  const calc = () => {
    try {
      const value = evaluateScientific(expr, degrees);
      setResult(
        value.toLocaleString(undefined, {
          maximumFractionDigits: Number.isFinite(precision) ? precision : 8,
        }),
      );
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Enter a valid expression.");
    }
  };
  const inputStyle = {
    backgroundColor: c.raised,
    color: c.text,
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    flex: 1,
  } as const;
  return isDiscount ? (
    <View style={{ gap: 13 }}>
      <Card
        style={{ backgroundColor: c.peach, borderColor: "transparent", gap: 6 }}
      >
        <Text style={{ color: c.text, fontSize: 18, fontWeight: "700" }}>
          What’s the sale price?
        </Text>
        <Text style={{ color: c.muted, fontSize: 12 }}>
          Calculate savings and optionally add local tax.
        </Text>
      </Card>
      <Card style={{ gap: 10 }}>
        <View style={{ flexDirection: "row", gap: 9 }}>
          <TextInput
            keyboardType="decimal-pad"
            value={price}
            onChangeText={setPrice}
            placeholder="Original price"
            placeholderTextColor={c.muted}
            style={inputStyle}
          />
          <TextInput
            keyboardType="decimal-pad"
            value={discount}
            onChangeText={setDiscount}
            placeholder="Discount %"
            placeholderTextColor={c.muted}
            style={inputStyle}
          />
        </View>
        <View style={{ flexDirection: "row", gap: 9 }}>
          <TextInput
            keyboardType="decimal-pad"
            value={tax}
            onChangeText={setTax}
            placeholder="Tax % (optional)"
            placeholderTextColor={c.muted}
            style={inputStyle}
          />
          <View style={{ flex: 1, justifyContent: "center" }}>
            <Text style={{ color: c.muted, fontSize: 11 }}>
              Currency: {toolPrefs.discount?.currency ?? "$ USD"}
            </Text>
          </View>
        </View>
        <ActionButton
          label="Calculate discount"
          icon="percent"
          onPress={discountResult}
        />
        {error ? (
          <Text style={{ color: "#B44A3A", fontSize: 12 }}>{error}</Text>
        ) : null}
        {result ? (
          <View
            style={{
              backgroundColor: c.greenSoft,
              borderRadius: 12,
              padding: 14,
            }}
          >
            <Text style={{ color: c.green, fontSize: 16, fontWeight: "700" }}>
              {result}
            </Text>
          </View>
        ) : null}
      </Card>
    </View>
  ) : (
    <View style={{ gap: 13 }}>
      <Card
        style={{
          backgroundColor: c.lavender,
          borderColor: "transparent",
          gap: 6,
        }}
      >
        <Text style={{ color: c.text, fontSize: 18, fontWeight: "700" }}>
          A little more than arithmetic.
        </Text>
        <Text style={{ color: c.muted, fontSize: 12 }}>
          Use sin, cos, tan, roots, logarithms and powers.{" "}
          {degrees ? "Angles: degrees." : "Angles: radians."}
        </Text>
      </Card>
      <Card style={{ gap: 12 }}>
        <TextInput
          value={expr}
          onChangeText={setExpr}
          placeholder="e.g. sin(30) + sqrt(16)"
          placeholderTextColor={c.muted}
          style={{
            backgroundColor: c.raised,
            color: c.text,
            borderRadius: 12,
            padding: 14,
            fontSize: 17,
          }}
        />
        {result ? (
          <View
            style={{
              padding: 14,
              backgroundColor: c.greenSoft,
              borderRadius: 12,
            }}
          >
            <Text style={{ color: c.green, fontWeight: "700", fontSize: 23 }}>
              {result}
            </Text>
          </View>
        ) : null}
        {error ? (
          <Text style={{ color: "#B44A3A", fontSize: 12 }}>{error}</Text>
        ) : null}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
          {[
            "7",
            "8",
            "9",
            "÷",
            "4",
            "5",
            "6",
            "×",
            "1",
            "2",
            "3",
            "−",
            "0",
            ".",
            "(",
            ")",
            "sin(",
            "cos(",
            "tan(",
            "sqrt(",
            "log(",
            "ln(",
            "π",
            "^",
            "%",
            "!",
            "C",
            "⌫",
            "=",
          ].map((key) => (
            <View key={key} style={{ width: "22.5%" }}>
              <ActionButton
                label={key}
                secondary={key !== "="}
                onPress={() => {
                  setError("");
                  if (key === "=") calc();
                  else if (key === "C") {
                    setExpr("");
                    setResult("");
                  } else if (key === "⌫") setExpr((v) => v.slice(0, -1));
                  else setExpr((v) => v + key);
                }}
              />
            </View>
          ))}
        </View>
      </Card>
    </View>
  );
}
