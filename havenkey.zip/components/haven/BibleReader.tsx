import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { ActionButton, Card, Eyebrow, Pill } from "@/components/haven/ui";
import { BIBLE_BOOKS, KJV_NOTICE } from "@/lib/haven/catalog";
import { getChapter, getChapterCount } from "@/lib/haven/gospel";
import { useHaven, useHavenColors } from "@/lib/haven/store";
export function BibleReader() {
  const c = useHavenColors();
  const { addClip, toolPrefs } = useHaven();
  const [book, setBook] = useState(42);
  const [chapter, setChapter] = useState(1);
  const [verses, setVerses] = useState<string[]>([]);
  const [chapterCount, setChapterCount] = useState(21);
  const [showBooks, setShowBooks] = useState(false);
  const [busy, setBusy] = useState(true);
  const fontSize = Number(toolPrefs.bible?.fontSize ?? "16");
  const showNumbers = (toolPrefs.bible?.verseNumbers ?? "Show") === "Show";
  useEffect(() => {
    let alive = true;
    setBusy(true);
    Promise.all([getChapter(book, chapter), getChapterCount(book)]).then(
      ([text, count]) => {
        if (alive) {
          setVerses(text);
          setChapterCount(count);
          setBusy(false);
        }
      },
    );
    return () => {
      alive = false;
    };
  }, [book, chapter]);
  const changeBook = (index: number) => {
    setBook(index);
    setChapter(1);
    setShowBooks(false);
  };
  return (
    <View style={{ gap: 13 }}>
      <Card
        style={{
          backgroundColor: c.greenSoft,
          borderColor: "transparent",
          gap: 6,
        }}
      >
        <Eyebrow>COMPLETE KING JAMES VERSION · OFFLINE</Eyebrow>
        <Text style={{ color: c.text, fontWeight: "700", fontSize: 19 }}>
          Read every book, right here.
        </Text>
        <Text style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}>
          The full text is included in the app. No internet connection or
          account required.
        </Text>
      </Card>
      <Pressable onPress={() => setShowBooks(!showBooks)}>
        <Card
          style={{
            padding: 14,
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
          }}
        >
          <MaterialIcons name="menu-book" size={20} color={c.green} />
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.muted, fontSize: 10 }}>BOOK</Text>
            <Text
              style={{
                color: c.text,
                fontSize: 16,
                fontWeight: "700",
                marginTop: 3,
              }}
            >
              {BIBLE_BOOKS[book]}
            </Text>
          </View>
          <MaterialIcons
            name={showBooks ? "expand-less" : "expand-more"}
            size={22}
            color={c.muted}
          />
        </Card>
      </Pressable>
      {showBooks ? (
        <Card style={{ padding: 10, gap: 9 }}>
          <Eyebrow>OLD & NEW TESTAMENT · 66 BOOKS</Eyebrow>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {BIBLE_BOOKS.map((name, index) => (
              <Pill
                key={name}
                label={name}
                active={book === index}
                onPress={() => changeBook(index)}
              />
            ))}
          </View>
        </Card>
      ) : null}
      <View style={{ gap: 8 }}>
        <Text style={{ color: c.text, fontSize: 17, fontWeight: "700" }}>
          Chapter
        </Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 7, paddingBottom: 2 }}
        >
          {Array.from({ length: chapterCount }, (_, i) => i + 1).map(
            (number) => (
              <Pill
                key={number}
                label={`${number}`}
                active={chapter === number}
                onPress={() => setChapter(number)}
              />
            ),
          )}
        </ScrollView>
      </View>
      <Card style={{ gap: 12 }}>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text style={{ color: c.text, fontSize: 18, fontWeight: "700" }}>
            {BIBLE_BOOKS[book]} {chapter}
          </Text>
          <Text style={{ color: c.muted, fontSize: 10 }}>KJV</Text>
        </View>
        {busy ? (
          <Text style={{ color: c.muted }}>Opening bundled chapter…</Text>
        ) : (
          verses.map((verse, index) => (
            <Pressable
              key={`${chapter}-${index}`}
              onLongPress={() =>
                addClip(`${BIBLE_BOOKS[book]} ${chapter}:${index + 1} ${verse}`)
              }
              style={{
                flexDirection: "row",
                gap: 11,
                paddingVertical: 6,
                borderBottomWidth: index === verses.length - 1 ? 0 : 1,
                borderBottomColor: c.line,
              }}
            >
              {showNumbers ? (
                <Text
                  style={{
                    color: c.green,
                    fontSize: 11,
                    fontWeight: "800",
                    width: 18,
                    paddingTop: 3,
                  }}
                >
                  {index + 1}
                </Text>
              ) : null}
              <Text
                style={{
                  color: c.text,
                  fontSize,
                  lineHeight: Math.round(fontSize * 1.65),
                  flex: 1,
                }}
              >
                {verse}
              </Text>
            </Pressable>
          ))
        )}
        <Text style={{ color: c.muted, fontSize: 10 }}>
          Press and hold a verse to save it locally.
        </Text>
      </Card>
      <View style={{ flexDirection: "row", gap: 9 }}>
        <View style={{ flex: 1 }}>
          <ActionButton
            label="Previous"
            icon="chevron-left"
            secondary
            onPress={() =>
              chapter > 1
                ? setChapter(chapter - 1)
                : book > 0
                  ? changeBook(book - 1)
                  : undefined
            }
          />
        </View>
        <View style={{ flex: 1 }}>
          <ActionButton
            label="Next chapter"
            icon="chevron-right"
            onPress={() =>
              chapter < chapterCount
                ? setChapter(chapter + 1)
                : book < BIBLE_BOOKS.length - 1
                  ? changeBook(book + 1)
                  : undefined
            }
          />
        </View>
      </View>
      <Text style={{ color: c.muted, fontSize: 10, lineHeight: 16 }}>
        {KJV_NOTICE}
      </Text>
    </View>
  );
}
