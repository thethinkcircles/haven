import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { Pill } from "@/components/haven/ui";
import { useHaven, useHavenColors } from "@/lib/haven/store";
const choices: Record<
  string,
  { label: string; field: string; values: string[] }[]
> = {
  harmony: [
    {
      label: "Passage style",
      field: "detail",
      values: ["Concise", "Full verse"],
    },
  ],
  bible: [
    { label: "Text size", field: "fontSize", values: ["14", "16", "18", "20"] },
    { label: "Verse numbers", field: "verseNumbers", values: ["Show", "Hide"] },
  ],
  memory: [
    {
      label: "Daily review target",
      field: "dailyGoal",
      values: ["3", "5", "10"],
    },
    {
      label: "Review direction",
      field: "reviewDirection",
      values: ["Prompt first", "Answer first"],
    },
  ],
  plate: [
    {
      label: "Meal labels",
      field: "mealLabels",
      values: ["Breakfast/Lunch/Dinner", "Custom"],
    },
    {
      label: "Serving display",
      field: "serving",
      values: ["Simple portions", "Metric"],
    },
  ],
  notes: [
    {
      label: "Note cards",
      field: "noteTint",
      values: ["Sage", "Lavender", "Peach"],
    },
    { label: "Sort order", field: "sort", values: ["Newest", "Oldest"] },
  ],
  journal: [
    { label: "Reflection prompts", field: "prompts", values: ["On", "Off"] },
    { label: "Journal view", field: "view", values: ["Daily", "Freeform"] },
  ],
  todo: [
    { label: "Sort tasks", field: "sort", values: ["Created", "Alphabetical"] },
    { label: "Completed items", field: "completed", values: ["Show", "Hide"] },
  ],
  followup: [
    { label: "Sort follow-ups", field: "sort", values: ["Newest", "Oldest"] },
    { label: "Completed items", field: "completed", values: ["Show", "Hide"] },
  ],
  exercise: [
    {
      label: "Activity units",
      field: "unit",
      values: ["Minutes", "Kilometres", "Steps"],
    },
    { label: "Weekly target", field: "weeklyGoal", values: ["3", "4", "5"] },
  ],
  sleep: [
    { label: "Sleep goal", field: "goal", values: ["7 h", "8 h", "9 h"] },
    { label: "Clock", field: "clock", values: ["12-hour", "24-hour"] },
  ],
  calendar: [
    { label: "Week starts", field: "weekStart", values: ["Monday", "Sunday"] },
  ],
  prayer: [
    { label: "Answered prayers", field: "answered", values: ["Show", "Hide"] },
    { label: "Prayer list order", field: "sort", values: ["Newest", "Oldest"] },
  ],
  discount: [
    {
      label: "Currency",
      field: "currency",
      values: ["$ USD", "€ EUR", "£ GBP"],
    },
    { label: "Tax display", field: "tax", values: ["Exclude tax", "Add tax"] },
  ],
  calculator: [
    { label: "Angle mode", field: "angle", values: ["Degrees", "Radians"] },
    {
      label: "Result precision",
      field: "precision",
      values: ["4 decimals", "8 decimals", "Full"],
    },
  ],
};
export function ToolCustomizePanel({ tool }: { tool: string }) {
  const c = useHavenColors();
  const { toolPrefs, updateToolPrefs } = useHaven();
  const [open, setOpen] = useState(false);
  const config = choices[tool] ?? [];
  return (
    <View
      style={{
        borderRadius: 18,
        borderColor: c.line,
        borderWidth: 1,
        backgroundColor: c.surface,
        overflow: "hidden",
      }}
    >
      <Pressable
        onPress={() => setOpen(!open)}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 9,
          padding: 14,
        }}
      >
        <MaterialIcons name="tune" size={19} color={c.green} />
        <Text
          style={{ flex: 1, color: c.text, fontSize: 13, fontWeight: "700" }}
        >
          Customize this app
        </Text>
        <Text style={{ color: c.muted, fontSize: 11 }}>Saved on device</Text>
        <MaterialIcons
          name={open ? "expand-less" : "expand-more"}
          size={19}
          color={c.muted}
        />
      </Pressable>
      {open ? (
        <View style={{ paddingHorizontal: 14, paddingBottom: 14, gap: 12 }}>
          {config.map((option) => (
            <View key={option.field} style={{ gap: 7 }}>
              <Text style={{ color: c.muted, fontSize: 11, fontWeight: "600" }}>
                {option.label}
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {option.values.map((value) => (
                  <Pill
                    key={value}
                    label={value}
                    active={
                      (toolPrefs[tool]?.[option.field] ?? option.values[0]) ===
                      value
                    }
                    onPress={() => updateToolPrefs(tool, option.field, value)}
                  />
                ))}
              </View>
            </View>
          ))}
        </View>
      ) : null}
    </View>
  );
}
