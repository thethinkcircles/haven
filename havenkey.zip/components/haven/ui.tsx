import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import type { ReactNode } from "react";
import { Pressable, Text, View, type ViewStyle } from "react-native";
import { useHavenColors } from "@/lib/haven/store";
export function Eyebrow({ children }: { children: ReactNode }) {
  const c = useHavenColors();
  return (
    <Text
      style={{
        color: c.muted,
        fontSize: 10,
        fontWeight: "700",
        letterSpacing: 1.5,
        textTransform: "uppercase",
      }}
    >
      {children}
    </Text>
  );
}
export function Heading({ children, sub }: { children: string; sub?: string }) {
  const c = useHavenColors();
  return (
    <View style={{ gap: 6 }}>
      <Text
        style={{
          color: c.text,
          fontSize: 30,
          lineHeight: 35,
          fontWeight: "700",
          letterSpacing: -0.7,
        }}
      >
        {children}
      </Text>
      {sub ? (
        <Text style={{ color: c.muted, fontSize: 14, lineHeight: 20 }}>
          {sub}
        </Text>
      ) : null}
    </View>
  );
}
export function SectionTitle({
  children,
  trailing,
}: {
  children: ReactNode;
  trailing?: ReactNode;
}) {
  const c = useHavenColors();
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 12,
      }}
    >
      <Text style={{ color: c.text, fontWeight: "700", fontSize: 17 }}>
        {children}
      </Text>
      {trailing ? (
        <Text style={{ color: c.green, fontSize: 12, fontWeight: "700" }}>
          {trailing}
        </Text>
      ) : null}
    </View>
  );
}
export function Card({
  children,
  style,
}: {
  children: ReactNode;
  style?: ViewStyle;
}) {
  const c = useHavenColors();
  return (
    <View
      style={[
        {
          backgroundColor: c.surface,
          borderRadius: 24,
          borderWidth: 1,
          borderColor: c.line,
          padding: 18,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}
export function Pill({
  label,
  active,
  onPress,
}: {
  label: string;
  active?: boolean;
  onPress?: () => void;
}) {
  const c = useHavenColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: active ? c.green : c.raised,
        paddingHorizontal: 14,
        paddingVertical: 9,
        borderRadius: 20,
        opacity: pressed ? 0.72 : 1,
      })}
    >
      <Text
        style={{
          color: active ? "#fff" : c.text,
          fontSize: 12,
          fontWeight: "700",
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}
export function ActionButton({
  label,
  icon,
  onPress,
  secondary = false,
}: {
  label: string;
  icon?: keyof typeof MaterialIcons.glyphMap;
  onPress: () => void;
  secondary?: boolean;
}) {
  const c = useHavenColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: secondary ? c.raised : c.green,
        borderRadius: 16,
        paddingHorizontal: 16,
        minHeight: 48,
        flexDirection: "row",
        gap: 8,
        alignItems: "center",
        justifyContent: "center",
        opacity: pressed ? 0.78 : 1,
      })}
    >
      {icon ? (
        <MaterialIcons
          name={icon}
          size={18}
          color={secondary ? c.text : "#fff"}
        />
      ) : null}
      <Text
        style={{
          color: secondary ? c.text : "#fff",
          fontSize: 14,
          fontWeight: "700",
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}
export function IconBadge({
  icon,
  tint = "green",
  size = 48,
}: {
  icon: keyof typeof MaterialIcons.glyphMap;
  tint?: "green" | "lavender" | "peach";
  size?: number;
}) {
  const c = useHavenColors();
  const bg =
    tint === "green" ? c.greenSoft : tint === "lavender" ? c.lavender : c.peach;
  return (
    <View
      style={{
        width: size,
        height: size,
        backgroundColor: bg,
        borderRadius: size * 0.36,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <MaterialIcons name={icon} size={size * 0.48} color={c.green} />
    </View>
  );
}
