import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { ActionButton, Card, Eyebrow } from "@/components/haven/ui";
import { useHaven, useHavenColors } from "@/lib/haven/store";
const ymd = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
export function CalendarTool() {
  const c = useHavenColors();
  const { tools, addRecord, removeRecord, toolPrefs } = useHaven();
  const now = new Date();
  const [month, setMonth] = useState(
    new Date(now.getFullYear(), now.getMonth(), 1),
  );
  const [selected, setSelected] = useState(ymd(now));
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const sunday = (toolPrefs.calendar?.weekStart ?? "Monday") === "Sunday";
  const offset =
    (new Date(month.getFullYear(), month.getMonth(), 1).getDay() +
      (sunday ? 0 : 6)) %
    7;
  const days = Array.from(
    {
      length: new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate(),
    },
    (_, i) => i + 1,
  );
  const label = month.toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });
  const entries = useMemo(
    () =>
      [...(tools.calendar ?? [])].filter((item) =>
        item.title.startsWith(`${selected} ·`),
      ),
    [tools.calendar, selected],
  );
  const dayLabels = sunday
    ? ["S", "M", "T", "W", "T", "F", "S"]
    : ["M", "T", "W", "T", "F", "S", "S"];
  return (
    <View style={{ gap: 14 }}>
      <Card
        style={{
          backgroundColor: c.lavender,
          borderColor: "transparent",
          gap: 8,
        }}
      >
        <Eyebrow>YOUR MONTH · STORED OFFLINE</Eyebrow>
        <Text style={{ color: c.text, fontSize: 19, fontWeight: "700" }}>
          Dates that matter to you.
        </Text>
        <Text style={{ color: c.muted, fontSize: 12 }}>
          Tap a date to see the agenda and add a private event.
        </Text>
      </Card>
      <Card style={{ gap: 12 }}>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Pressable
            onPress={() =>
              setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))
            }
          >
            <MaterialIcons name="chevron-left" color={c.green} size={24} />
          </Pressable>
          <Text style={{ color: c.text, fontSize: 16, fontWeight: "700" }}>
            {label}
          </Text>
          <Pressable
            onPress={() =>
              setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))
            }
          >
            <MaterialIcons name="chevron-right" color={c.green} size={24} />
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-around" }}>
          {dayLabels.map((day, index) => (
            <Text
              key={`${day}${index}`}
              style={{
                width: "13.5%",
                textAlign: "center",
                color: c.muted,
                fontSize: 10,
                fontWeight: "700",
              }}
            >
              {day}
            </Text>
          ))}
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          {Array.from({ length: offset }, (_, i) => (
            <View key={`blank-${i}`} style={{ width: "14.28%", height: 40 }} />
          ))}
          {days.map((day) => {
            const key = ymd(
              new Date(month.getFullYear(), month.getMonth(), day),
            );
            const hasEvent = (tools.calendar ?? []).some((item) =>
              item.title.startsWith(`${key} ·`),
            );
            return (
              <Pressable
                key={day}
                onPress={() => setSelected(key)}
                style={{
                  width: "14.28%",
                  height: 40,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <View
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 15,
                    backgroundColor: selected === key ? c.green : "transparent",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text
                    style={{
                      color: selected === key ? "#fff" : c.text,
                      fontSize: 12,
                      fontWeight: selected === key ? "700" : "500",
                    }}
                  >
                    {day}
                  </Text>
                </View>
                {hasEvent ? (
                  <View
                    style={{
                      position: "absolute",
                      bottom: 1,
                      width: 4,
                      height: 4,
                      borderRadius: 3,
                      backgroundColor: c.green,
                    }}
                  />
                ) : null}
              </Pressable>
            );
          })}
        </View>
        <Text style={{ color: c.muted, fontSize: 11 }}>
          {new Date(`${selected}T12:00:00`).toLocaleDateString(undefined, {
            weekday: "long",
            month: "long",
            day: "numeric",
          })}
        </Text>
      </Card>
      <Card style={{ gap: 9 }}>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Event or reminder"
          placeholderTextColor={c.muted}
          style={{
            backgroundColor: c.raised,
            color: c.text,
            borderRadius: 12,
            padding: 12,
            fontSize: 14,
          }}
        />
        <TextInput
          value={note}
          onChangeText={setNote}
          placeholder="A note (optional)"
          placeholderTextColor={c.muted}
          style={{
            backgroundColor: c.raised,
            color: c.text,
            borderRadius: 12,
            padding: 12,
            fontSize: 13,
          }}
        />
        <ActionButton
          label="Save to this day"
          icon="event-available"
          onPress={() => {
            if (title.trim()) {
              addRecord(
                "calendar",
                `${selected} · ${title.trim()}`,
                note.trim(),
              );
              setTitle("");
              setNote("");
            }
          }}
        />
      </Card>
      <View style={{ gap: 8 }}>
        <Text style={{ color: c.text, fontSize: 15, fontWeight: "700" }}>
          Agenda · {entries.length}
        </Text>
        {entries.length ? (
          entries.map((record) => (
            <Card
              key={record.id}
              style={{
                padding: 13,
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
              }}
            >
              <MaterialIcons name="event" size={18} color={c.green} />
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: c.text, fontSize: 13, fontWeight: "700" }}
                >
                  {record.title.split(" · ").slice(1).join(" · ")}
                </Text>
                {record.body ? (
                  <Text style={{ color: c.muted, fontSize: 11, marginTop: 3 }}>
                    {record.body}
                  </Text>
                ) : null}
              </View>
              <Pressable onPress={() => removeRecord("calendar", record.id)}>
                <MaterialIcons name="close" size={17} color={c.muted} />
              </Pressable>
            </Card>
          ))
        ) : (
          <Text style={{ color: c.muted, fontSize: 12 }}>
            No events for this day yet.
          </Text>
        )}
      </View>
    </View>
  );
}
