import { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  Text,
  TextInput,
  View,
} from "react-native";
import { ActionButton, Card, Eyebrow } from "@/components/haven/ui";
import { BIBLE_BOOKS, KJV_NOTICE } from "@/lib/haven/catalog";
import type { VerseRange } from "@/lib/haven/gospel";
import { getGospelPassage } from "@/lib/haven/gospel";
import { useHaven, useHavenColors } from "@/lib/haven/store";
import harmonyIndex from "@/lib/haven/harmony-data.json";

type GospelName = "Matthew" | "Mark" | "Luke" | "John";
type Passage = { reference: string; ranges: VerseRange[] } | null;
type HarmonyEntry = {
  id: number;
  sectionId: string;
  order: number;
  title: string;
  setting: string;
  accounts: Record<GospelName, Passage>;
  supplementary: { reference: string; ranges: VerseRange[] }[];
};
type HarmonyIndex = {
  source: string;
  sourceUrl: string;
  methodNote: string;
  eventCount: number;
  events: HarmonyEntry[];
};

const INDEX = harmonyIndex as HarmonyIndex;
const GOSPELS: GospelName[] = ["Matthew", "Mark", "Luke", "John"];
const PAGE_SIZE = 20;

function bookFromReference(reference: string) {
  const match = reference.match(/^(.+?)\s+\d+:/);
  return match?.[1] && BIBLE_BOOKS.includes(match[1]) ? match[1] : null;
}

function HarmonyEventCard({
  event,
  expanded,
  onToggle,
}: {
  event: HarmonyEntry;
  expanded: boolean;
  onToggle: () => void;
}) {
  const c = useHavenColors();
  const { addClip, toolPrefs } = useHaven();
  const [loading, setLoading] = useState(false);
  const [passages, setPassages] = useState<Partial<Record<GospelName, string>>>(
    {},
  );
  const [supplementary, setSupplementary] = useState<
    { reference: string; text: string }[]
  >([]);
  const compact = toolPrefs.harmony?.detail !== "Full verse";

  useEffect(() => {
    if (!expanded) return;
    let active = true;
    setLoading(true);
    const load = async () => {
      const accountResults = await Promise.all(
        GOSPELS.map(async (name) => {
          const account = event.accounts[name];
          const text = account
            ? await getGospelPassage(name, account.ranges)
            : "";
          return [name, text] as const;
        }),
      );
      const extraResults = await Promise.all(
        event.supplementary.map(async (item) => {
          const book = bookFromReference(item.reference);
          const text = book ? await getGospelPassage(book, item.ranges) : "";
          return { reference: item.reference, text };
        }),
      );
      if (active) {
        setPassages(Object.fromEntries(accountResults));
        setSupplementary(extraResults);
        setLoading(false);
      }
    };
    void load().catch(() => {
      if (active) setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [event, expanded]);

  const copyText = GOSPELS.flatMap((name) => {
    const account = event.accounts[name];
    const text = passages[name];
    return account && text ? [`${account.reference}\n${text}`] : [];
  }).join("\n\n");

  return (
    <Card style={{ padding: 0, overflow: "hidden" }}>
      <Pressable
        onPress={onToggle}
        accessibilityRole="button"
        accessibilityLabel={`${expanded ? "Collapse" : "Expand"} section ${event.sectionId}: ${event.title}`}
        style={({ pressed }) => ({
          padding: 16,
          gap: 6,
          backgroundColor: expanded ? c.greenSoft : c.surface,
          opacity: pressed ? 0.82 : 1,
        })}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View style={{ flex: 1, gap: 4 }}>
            <Eyebrow>
              EVENT {event.order} · SECTION {event.sectionId}
            </Eyebrow>
            <Text
              style={{
                color: c.text,
                fontSize: 15,
                lineHeight: 21,
                fontWeight: "700",
              }}
            >
              {event.title}
            </Text>
          </View>
          <Text style={{ color: c.green, fontSize: 20 }}>
            {expanded ? "−" : "+"}
          </Text>
        </View>
        {event.setting ? (
          <Text style={{ color: c.muted, fontSize: 11 }}>{event.setting}</Text>
        ) : null}
        <Text style={{ color: c.muted, fontSize: 10 }}>
          {GOSPELS.map((name) => event.accounts[name]?.reference ?? "—").join(
            "  ·  ",
          )}
        </Text>
      </Pressable>

      {expanded ? (
        <View style={{ padding: 14, gap: 12 }}>
          {GOSPELS.map((name) => {
            const account = event.accounts[name];
            return (
              <View
                key={name}
                style={{
                  gap: 5,
                  borderTopWidth: 1,
                  borderTopColor: c.line,
                  paddingTop: 10,
                }}
              >
                <Text
                  style={{ color: c.green, fontSize: 12, fontWeight: "700" }}
                >
                  {name}
                  {account
                    ? ` · ${account.reference}`
                    : " · no parallel passage listed"}
                </Text>
                <Text
                  style={{
                    color: account ? c.text : c.muted,
                    fontSize: compact ? 13 : 16,
                    lineHeight: compact ? 20 : 27,
                  }}
                >
                  {account
                    ? loading
                      ? "Loading bundled KJV passage…"
                      : passages[name] ||
                        "This passage is not available in the bundled KJV text."
                    : "No passage is listed for this event in this Gospel."}
                </Text>
              </View>
            );
          })}
          {event.supplementary.length ? (
            <View
              style={{
                gap: 7,
                borderTopWidth: 1,
                borderTopColor: c.line,
                paddingTop: 10,
              }}
            >
              <Text style={{ color: c.muted, fontSize: 11, fontWeight: "700" }}>
                SUPPLEMENTARY READINGS
              </Text>
              {supplementary.map((item) => (
                <View key={item.reference} style={{ gap: 4 }}>
                  <Text
                    style={{ color: c.green, fontSize: 12, fontWeight: "700" }}
                  >
                    {item.reference}
                  </Text>
                  <Text
                    style={{
                      color: c.text,
                      fontSize: compact ? 13 : 16,
                      lineHeight: compact ? 20 : 27,
                    }}
                  >
                    {loading
                      ? "Loading bundled KJV passage…"
                      : item.text ||
                        "Passage not available in the bundled KJV text."}
                  </Text>
                </View>
              ))}
            </View>
          ) : null}
          {loading ? <ActivityIndicator color={c.green} /> : null}
          <Text style={{ color: c.muted, fontSize: 10 }}>
            King James Version · bundled on this device
          </Text>
          {copyText ? (
            <ActionButton
              label="Copy listed Gospel passages"
              icon="content-copy"
              onPress={() => addClip(copyText)}
              secondary
            />
          ) : null}
        </View>
      ) : null}
    </Card>
  );
}

export function GospelHarmony() {
  const c = useHavenColors();
  const [query, setQuery] = useState("");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    if (!needle) return INDEX.events;
    return INDEX.events.filter((event) => {
      const searchable = [
        event.title,
        event.setting,
        event.sectionId,
        ...GOSPELS.map((name) => event.accounts[name]?.reference ?? ""),
        ...event.supplementary.map((item) => item.reference),
      ]
        .join(" ")
        .toLocaleLowerCase();
      return searchable.includes(needle);
    });
  }, [query]);
  const visible = filtered.slice(0, visibleCount);

  return (
    <View style={{ gap: 13 }}>
      <Card
        style={{
          backgroundColor: c.greenSoft,
          borderColor: "transparent",
          gap: 8,
        }}
      >
        <Eyebrow>COMPLETE FOUR-GOSPEL HARMONY · KJV</Eyebrow>
        <Text style={{ color: c.text, fontSize: 20, fontWeight: "700" }}>
          An ordered Gospel timeline
        </Text>
        <Text style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}>
          {INDEX.eventCount} source sections · Matthew, Mark, Luke and John ·
          passages open from the bundled KJV as you need them.
        </Text>
        <Text style={{ color: c.muted, fontSize: 10, lineHeight: 15 }}>
          {INDEX.methodNote}
        </Text>
      </Card>
      <TextInput
        value={query}
        onChangeText={(value) => {
          setQuery(value);
          setVisibleCount(PAGE_SIZE);
        }}
        placeholder="Search events, places or references"
        placeholderTextColor={c.muted}
        accessibilityLabel="Search the Gospel chronology"
        style={{
          backgroundColor: c.surface,
          color: c.text,
          borderRadius: 16,
          borderWidth: 1,
          borderColor: c.line,
          paddingHorizontal: 14,
          paddingVertical: 12,
          fontSize: 14,
        }}
      />
      <Text style={{ color: c.muted, fontSize: 11 }}>
        Showing {visible.length} of {filtered.length}{" "}
        {query ? "matches" : "chronological sections"}
      </Text>
      {visible.map((event) => (
        <HarmonyEventCard
          key={event.id}
          event={event}
          expanded={expandedId === event.id}
          onToggle={() =>
            setExpandedId(expandedId === event.id ? null : event.id)
          }
        />
      ))}
      {visibleCount < filtered.length ? (
        <ActionButton
          label={`Show next ${Math.min(PAGE_SIZE, filtered.length - visibleCount)} sections`}
          icon="expand-more"
          secondary
          onPress={() => setVisibleCount((count) => count + PAGE_SIZE)}
        />
      ) : null}
      <Card style={{ gap: 7 }}>
        <Text style={{ color: c.green, fontSize: 11, fontWeight: "700" }}>
          SOURCE · {INDEX.source}
        </Text>
        <Text style={{ color: c.muted, fontSize: 10, lineHeight: 15 }}>
          {KJV_NOTICE}
        </Text>
      </Card>
    </View>
  );
}
