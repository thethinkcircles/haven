import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { ActionButton, Card, Eyebrow } from "@/components/haven/ui";
import { useHaven, useHavenColors } from "@/lib/haven/store";
import type { HavenRecord } from "@/lib/haven/store";
export function PrayerTool({ records }: { records: HavenRecord[] }) {
  const c = useHavenColors();
  const { addRecord, toggleRecord, removeRecord } = useHaven();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  return (
    <View style={{ gap: 13 }}>
      <Card
        style={{ backgroundColor: c.peach, borderColor: "transparent", gap: 7 }}
      >
        <Eyebrow>A PRIVATE SPACE · OFFLINE</Eyebrow>
        <Text style={{ color: c.text, fontSize: 18, fontWeight: "700" }}>
          A moment for what’s on your heart.
        </Text>
        <Text style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}>
          Your prayer notes stay on this device. Add a name, intention, or quiet
          reflection.
        </Text>
      </Card>
      <Card style={{ gap: 9 }}>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Prayer or intention"
          placeholderTextColor={c.muted}
          style={{
            backgroundColor: c.raised,
            color: c.text,
            borderRadius: 12,
            padding: 12,
            fontSize: 14,
          }}
        />
        <TextInput
          value={body}
          onChangeText={setBody}
          placeholder="A private note (optional)"
          placeholderTextColor={c.muted}
          multiline
          style={{
            backgroundColor: c.raised,
            color: c.text,
            borderRadius: 12,
            padding: 12,
            minHeight: 72,
            textAlignVertical: "top",
            fontSize: 13,
          }}
        />
        <ActionButton
          label="Add prayer"
          icon="add"
          onPress={() => {
            if (title.trim()) {
              addRecord("prayer", title.trim(), body.trim());
              setTitle("");
              setBody("");
            }
          }}
        />
      </Card>
      <Text style={{ color: c.muted, fontSize: 11, fontWeight: "700" }}>
        YOUR PRAYER LIST · {records.length}
      </Text>
      {records.length ? (
        records.map((entry) => (
          <Card
            key={entry.id}
            style={{
              padding: 14,
              flexDirection: "row",
              gap: 10,
              alignItems: "flex-start",
            }}
          >
            <Pressable onPress={() => toggleRecord("prayer", entry.id)}>
              <MaterialIcons
                name={entry.done ? "favorite" : "favorite-border"}
                size={20}
                color={entry.done ? c.green : c.muted}
              />
            </Pressable>
            <View style={{ flex: 1, gap: 5 }}>
              <Text style={{ color: c.text, fontSize: 14, fontWeight: "700" }}>
                {entry.title}
              </Text>
              {entry.body ? (
                <Text style={{ color: c.muted, fontSize: 12, lineHeight: 18 }}>
                  {entry.body}
                </Text>
              ) : null}
              <Text style={{ color: c.green, fontSize: 10 }}>
                {entry.done ? "Marked as answered" : "Still on your heart"} ·{" "}
                {new Date(entry.createdAt).toLocaleDateString()}
              </Text>
            </View>
            <Pressable onPress={() => removeRecord("prayer", entry.id)}>
              <MaterialIcons name="close" size={17} color={c.muted} />
            </Pressable>
          </Card>
        ))
      ) : (
        <Text style={{ color: c.muted, fontSize: 12 }}>
          Your prayer list is empty. You can start whenever you’re ready.
        </Text>
      )}
    </View>
  );
}
