# Haven — mindful keyboard

## Implementation approach

Keep the managed Expo / React Native / TypeScript mobile starter as Haven’s local-only companion app and keyboard playground. Add the system-wide Android keyboard separately as a native `InputMethodService` with Jetpack Compose and Material 3 through the Expo config plugin. The companion UI remains React Native; the actual Android keyboard uses Compose. The primary number row is optional and configurable in the preview and in Android’s native IME settings.

LeanType is an ergonomic feature reference only. Upstream keyboard/prediction code is GPL-3.0-only; the user explicitly declined importing that engine, dictionaries or license obligations. No LeanType code, models or assets are in Haven. Use only a small first-party offline prefix/correction list, direct composition and no Android system spell-checker or network prediction service. Include cross-row glide tracking, long-press alternatives, local clipboard, an editor toolbar (cursor movement, selection, select-all, cut/copy/paste, undo/redo), multilingual QWERTY and secure-field safeguards. This is a Gboard-inspired original keyboard, not a reproduction of proprietary predictive models.

Replace the representative Gospel Harmony sample with the complete ordered Gospel sequence from A. T. Robertson’s 1922 _A Harmony of the Gospels for Students of the Life of Christ_ (Project Gutenberg eBook 36264). Extract every numbered narrative section, including lettered sections, preserve events found in a single Gospel, and show Matthew/Mark/Luke/John side-by-side. Use only passage references/order from this public-domain harmony; render the actual King James Version from the bundled local dataset. Include source attribution and a note that a harmony is one scholarly ordering, not a universally agreed historical timeline. Add searchable event navigation; selecting a Gospel with no parallel must clearly say so. Support passage ranges that cross chapter boundaries.

Toolbar includes Gospel Harmony, full offline KJV Bible, Memory Builder, Plate meal log, Sticky Notes, Journal, To Do, Follow-up, Exercise, Sleep, interactive Calendar, Prayer, Discount Calculator and Scientific Calculator. Each tool operates locally and has relevant per-tool customization persisted on-device: Bible size/verse controls; study/review options; note and log display/category fields; calendar week start; prayer/list presentation; exercise/sleep units/goals; calculator currency/tax/angle/precision. Keyboard options include number row, theme, language, key size, haptics, silence and glide. No accounts, sync, analytics, sensors, health diagnosis, network calls or push reminders. The initial unfinished word “wit” after “sleep app” has no inferred requirement.

## Platform and build constraints

The app preview uses Expo Web/Go, whereas system-wide typing needs the custom Android input method installed/enabled in Android Settings. The user authorized Google's SDK licenses and Gradle `assembleDebug` was attempted. No APK was produced: this Sandbox is AArch64, but the installed Google Android CMake, NDK and AAPT2 executables are x86-64 and fail in native compilation/resource processing. A compatible x86-64 build runner is required before claiming a downloadable APK. Any such local artifact is debug-signed, not a production release. The Webdev Expo guidance reserves native release artifacts for the Dashboard; do not run an Android release build in Sandbox. Preserve the fixed Metro 8081/API 3000 setup; Haven user data does not use the starter backend/database.

Target lightweight 60-FPS transitions without claiming an unmeasured guarantee. Use adaptive key sizing for phones/tablets, bounded clipboard/candidate history, small local state, lazy KJV loading and concise list rendering. KJV JSON is bundled and loaded on demand. Preferences and personal records live in AsyncStorage; the app has no network feature requirement.

## Project structure

- `app/(tabs)/`: Home, Keyboard playground, Tools and Settings.
- `app/tool/[id].tsx`: shared routes for all fourteen tools and their customization.
- `components/haven/`: UI primitives, keyboard preview, Bible reader, calendar, prayer and calculators.
- `lib/haven/`: device-local state, tool metadata, expression parser, complete Gospel Harmony event index and lazy KJV passage loader.
- `assets/data/third-party/`: bundled full KJV JSON with its source/license notice.
- `plugins/with-haven-ime.cjs`: repeatable Android Compose service/metadata/Gradle source generation and native IME settings.
- `android/`: generated Expo project used for SDK/Gradle compilation and debug APK output; not the committed source of truth.
- `lib/haven/*.test.ts`: deterministic offline calculator tests and full Harmony-section/KJV-range integrity checks.
- The untouched starter server/database remain unused for Haven user data.

## Design

Considered styles: **Warm modernist utility** (<0.10 probability), **Soft editorial sanctuary** (<0.10), and **Neo-technical instrument panel** (<0.10). Choose **Warm modernist utility**. Use familiar adaptive keyboard ergonomics and Material 3 touch targets with an original, quieter Haven identity. Core principles: legible hierarchy, tactile keys, one-handed actions and privacy made understandable. Palette: creamy off-white, deep ink, ownable olive `#6C7A50`, sage, lavender and warm peach; charcoal-olive dark mode.

**Layout:** editorial left-aligned greeting, featured keyboard preview, next-action strip and compact tool tiles, not a generic centered dashboard. **Motifs:** split-key H, green active dot, lavender keyboard well and pill mode controls. **Interaction:** clear labels and immediate local feedback. **Animation:** 100–160 ms key feedback, 180–240 ms transitions, no heavy parallax. **Typography:** Android Roboto/system sans, 30–32 px headlines, 18–20 px sections, 13–15 px body, 10–11 px micro-labels.

**Brand essence:** a private keyboard that keeps everyday thoughts, faith and wellbeing close at hand. Personality: calm, capable, considerate. Voice: “A little more space for your thoughts.” “Your words stay with you.” **Wordmark/logo:** lower-case haven with a four-key H mark. **Signature color:** olive `#6C7A50`.

## References and notices

- Chronological arrangement: A. T. Robertson, _A Harmony of the Gospels for Students of the Life of Christ_ (1922), public-domain Project Gutenberg eBook 36264: https://www.gutenberg.org/files/36264/36264-h/36264-h.htm . The book is based on the Broadus Harmony and Revised Version; Haven uses its chronology/references while displaying the locally bundled KJV. Event ordering/parallel judgments can differ across harmonies.
- KJV data: https://github.com/thiagobodruk/bible . Retain the included source/license notice and note jurisdiction-specific rights for the KJV.
- LeanType reference: https://github.com/LeanBitLab/LeanType and https://f-droid.org/en/packages/com.leanbitlab.leantype/ . Upstream GPL-3.0-only; user declined code/model import. No LeanType assets or source are included.
- Android input-method reference: https://developer.android.com/develop/ui/views/touch-and-input/creating-input-method .
